import os
import re
import requests
import pytz
from fastapi import FastAPI, HTTPException, status, Request, BackgroundTasks, Query, Form, File, UploadFile, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr
from typing import Optional, Dict, Any
from dotenv import load_dotenv
from supabase import create_client, Client, ClientOptions
from datetime import datetime
from uuid import uuid4
import uuid
import firebase_admin
from firebase_admin import credentials, messaging
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
# Cargar variables de entorno
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE_DIR, ".env"))

from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from fastapi.responses import JSONResponse, StreamingResponse
import io
import csv

limiter = Limiter(key_func=get_remote_address)

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_SERVICE_ROLE_KEY")

if not SUPABASE_URL or not SUPABASE_KEY:
    raise ValueError("Faltan variables de entorno SUPABASE_URL o SUPABASE_SERVICE_ROLE_KEY")

# Inicializar cliente Supabase con ClientOptions para evitar errores de JWT en el backend
opts = ClientOptions(
    auto_refresh_token=False,
    persist_session=False
)
supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY, options=opts)

# ─── SCHEDULER AUTOMÁTICO DE MORA ──────────────────────────────────────────
import logging
logger = logging.getLogger(__name__)

def tarea_automatica_mora():
    """
    Se ejecuta automáticamente el día 11 de cada mes a las 8:00 AM (hora Argentina).
    Detecta socios sin pago del mes y les envía WhatsApp de aviso.
    """
    hoy = datetime.now()
    mes_actual = hoy.month
    anio_actual = hoy.year
    fecha_venci = f"{anio_actual}-{mes_actual:02d}-10"
    logger.info(f"[SCHEDULER] Ejecutando detección automática de mora para {mes_actual}/{anio_actual}")
    
    try:
        socios_res = supabase.table("profiles").select("id, nombre_apellido, telefono") \
            .eq("rol", "SOCIO").in_("estado", ["APROBADO", "RESTRINGIDO"]) \
            .ilike("nombre_apellido", "%Vic Tor%").execute()
        socios = socios_res.data or []
        detectados = 0
        
        # O(1) Performance Optimization: Fetch all payments for this month once
        todos_pagos_res = supabase.table("pagos_cuotas") \
            .select("socio_id") \
            .eq("fecha_vencimiento", fecha_venci) \
            .in_("estado_pago", ["PAGADO", "PENDIENTE_VALIDACION"]) \
            .execute()
        pagos_al_dia = {p["socio_id"] for p in (todos_pagos_res.data or [])}
        
        for socio in socios:
            if socio["id"] not in pagos_al_dia:
                # Marcar como RESTRINGIDO
                supabase.table("profiles").update({
                    "estado": "RESTRINGIDO",
                    "motivo": f"Mora automática cuota {mes_actual}/{anio_actual}"
                }).eq("id", socio["id"]).execute()
                
                # Registrar deuda
                supabase.table("pagos_cuotas").upsert({
                    "socio_id": socio["id"],
                    "monto": 5000,
                    "fecha_vencimiento": fecha_venci,
                    "estado_pago": "PENDIENTE"
                }, on_conflict="socio_id,fecha_vencimiento").execute()
                
                # Log
                supabase.table("activity_log").insert({
                    "socio_id": socio["id"],
                    "tipo_evento": "MORA_DETECTADA",
                    "descripcion": f"Detección automática de mora para cuota {mes_actual}/{anio_actual}",
                    "usuario_id": None
                }).execute()
                
                # WhatsApp
                if socio.get("telefono"):
                    mensaje_wa = (
                        f"Hola {socio['nombre_apellido']}! 👋\n"
                        f"Detectamos un atraso en el pago de tu cuota de la Sociedad Rural ({mes_actual}/{anio_actual}).\n\n"
                        "¿Deseás regularizar tu situación? Respondé *SÍ*, *ACEPTO* o *PAGAR* para enviarte el detalle de tu deuda y el link de pago."
                    )
                    enviar_whatsapp(socio["telefono"], mensaje_wa)
                    detectados += 1
        
        logger.info(f"[SCHEDULER] Mora detectada: {detectados} socios notificados.")
    except Exception as e:
        logger.error(f"[SCHEDULER] Error en tarea automática de mora: {str(e)}")

# Zona horaria Argentina
TZ_ARGENTINA = pytz.timezone("America/Argentina/Buenos_Aires")

scheduler = BackgroundScheduler(timezone=TZ_ARGENTINA)
scheduler.add_job(
    tarea_automatica_mora,
    trigger=CronTrigger(day=11, hour=8, minute=0, timezone=TZ_ARGENTINA),
    id="mora_mensual",
    name="Detección automática de mora - día 11 a las 8:00 AM",
    replace_existing=True
)

app = FastAPI(title="Sociedad Rural Norte de Corrientes API")
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

@app.on_event("startup")
def startup_scheduler():
    scheduler.start()
    logger.info("[SCHEDULER] Iniciado. Motor de mora programado para el día 11 de cada mes a las 8:00 AM (AR).")

@app.on_event("shutdown")
def shutdown_scheduler():
    scheduler.shutdown(wait=False)
    logger.info("[SCHEDULER] Apagado correctamente.")

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    # Log the real error to the server console but don't leak details to the client
    print(f"Global Exception [500] -> {str(exc)}")
    return JSONResponse(
        status_code=500,
        content={"detail": "Ha ocurrido un error interno en el servidor. Si el problema persiste, contacte a soporte."},
    )

# --- INICIALIZAR FIREBASE ADMIN ---
def get_formatted_private_key() -> str:
    raw_key = os.environ.get("FIREBASE_PRIVATE_KEY", "")
    if not raw_key:
        return ""
    # Si viene con comillas dobles al principio y al final, las quitamos
    if raw_key.startswith('"') and raw_key.endswith('"'):
        raw_key = raw_key[1:-1]
    
    # Reemplazamos los saltos de línea escapados por saltos de línea reales
    formatted_key = raw_key.replace("\\n", "\n")
    
    # Asegurarnos de limpiar correctamente cualquier espacio o salto de linea mal formado
    if "-----BEGIN PRIVATE KEY-----" in formatted_key:
        try:
            key_body = formatted_key.split("-----BEGIN PRIVATE KEY-----")[1].split("-----END PRIVATE KEY-----")[0]
            clean_body = key_body.replace(" ", "").replace("\\n", "").replace("\n", "").replace("\r", "")
            chunks = [clean_body[i:i+64] for i in range(0, len(clean_body), 64)]
            formatted_key = "-----BEGIN PRIVATE KEY-----\n" + "\n".join(chunks) + "\n-----END PRIVATE KEY-----\n"
        except Exception:
            pass

    return formatted_key

try:
    firebase_default_app = firebase_admin.get_app()
except ValueError:
    firebase_cred_json = {
        "type": os.environ.get("FIREBASE_TYPE", "service_account"),
        "project_id": os.environ.get("FIREBASE_PROJECT_ID"),
        "private_key_id": os.environ.get("FIREBASE_PRIVATE_KEY_ID"),
        "private_key": get_formatted_private_key(),
        "client_email": os.environ.get("FIREBASE_CLIENT_EMAIL"),
        "client_id": os.environ.get("FIREBASE_CLIENT_ID"),
        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
        "token_uri": "https://oauth2.googleapis.com/token",
        "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
        "client_x509_cert_url": f"https://www.googleapis.com/robot/v1/metadata/x509/{os.environ.get('FIREBASE_CLIENT_EMAIL', '').replace('@', '%40')}",
        "universe_domain": "googleapis.com"
    }
    # Solo inicializar si tenemos al menos el project_id y private_key validos
    if firebase_cred_json.get("project_id") and firebase_cred_json.get("private_key"):
        try:
            cred = credentials.Certificate(firebase_cred_json)
            firebase_admin.initialize_app(cred)
            print("Firebase Admin configurado correctamente.")
        except Exception as e:
            print(f"Warning: Firebase Admin no pudo inicializarse: {e}")
    else:
        print("Warning: Faltan credenciales de Firebase en el entorno, Push Notifications deshabilitadas.")

# --- FUNCIONES DE AUDITORÍA ---
def registrar_auditoria(
    usuario_id: Optional[str],
    email_usuario: Optional[str],
    rol_usuario: Optional[str],
    accion: str,
    tabla: str,
    registro_id: str,
    datos_anteriores: Optional[Dict[str, Any]],
    datos_nuevos: Optional[Dict[str, Any]],
    modulo: str,
    request: Request
):
    """
    Registra un evento crítico en la tabla auditoria_logs.
    """
    try:
        ip = request.client.host if request.client else "unknown"
        user_agent = request.headers.get("user-agent", "unknown")
        
        log_data = {
            "usuario_id": usuario_id,
            "email_usuario": email_usuario,
            "rol_usuario": rol_usuario,
            "accion": accion,
            "tabla_afectada": tabla,
            "registro_id": registro_id,
            "datos_anteriores": datos_anteriores,
            "datos_nuevos": datos_nuevos,
            "modulo": modulo,
            "ip_address": ip,
            "user_agent": user_agent
        }
        
        supabase.table("auditoria_logs").insert(log_data).execute()
    except Exception as e:
        # La auditoría no debería bloquear el flujo principal si falla,
        # pero idealmente debería registrarse en un log del servidor.
        print(f"Error crítico en registro de auditoría: {str(e)}")

# 1. CORS ESTRICTO PARA FRONTEND (localhost:3000 y dominios de producción)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000", 
        "http://localhost:5173", 
        "http://127.0.0.1:5173",
        "https://agentech.ar",
        "https://www.agentech.ar",
        "https://sociedadrural.agentech.ar",
        "https://sociedadruraldelnorte.agentech.ar"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 2. MODELOS PYDANTIC BASADOS EN FORMULARIOS DEL FRONTEND
class RegisterRequest(BaseModel):
    nombre_apellido: str
    dni_cuit: str
    email: EmailStr
    telefono: str
    rol: Optional[str] = "SOCIO"
    municipio: Optional[str] = None
    rubro: Optional[str] = None
    direccion: Optional[str] = None
    es_profesional: Optional[bool] = False
    password: Optional[str] = None
    camara_denominacion: Optional[str] = None
    camara_provincia: Optional[str] = None

class LoginRequest(BaseModel):
    identificador: str
    password: str

class ForgotPasswordRequest(BaseModel):
    identificador: str
    mensaje: Optional[str] = None

class UpdateProfileRequest(BaseModel):
    nombre_apellido: Optional[str] = None
    telefono: Optional[str] = None
    municipio: Optional[str] = None
    rubro: Optional[str] = None
    email: Optional[str] = None
    direccion: Optional[str] = None

class CreateAdminRequest(BaseModel):
    username: str
    email: EmailStr
    password: str
    nombre_apellido: str
    dni: Optional[str] = None
    rol: str

class UpdateAdminRoleRequest(BaseModel):
    rol: str

class ResetPasswordRequest(BaseModel):
    new_password: str

class AddDependienteRequest(BaseModel):
    nombre_apellido: str
    dni_cuit: str
    tipo_vinculo: str
    email: Optional[EmailStr] = None
    telefono: Optional[str] = None
    password: Optional[str] = None

class EventCreate(BaseModel):
    titulo: str
    descripcion: str
    lugar: str
    fecha: str
    hora: str
    tipo: str
    imagen_url: Optional[str] = None

class EventUpdate(BaseModel):
    titulo: Optional[str] = None
    descripcion: Optional[str] = None
    lugar: Optional[str] = None
    fecha: Optional[str] = None
    hora: Optional[str] = None
    tipo: Optional[str] = None
    imagen_url: Optional[str] = None

class WebhookEventoPayload(BaseModel):
    post_id: str
    caption: str
    media_url: str
    timestamp: str

# ── UTILIDADES PARA EL WEBHOOK DE EVENTOS SOCIALES ───────────────────────────
def procesar_texto_evento(caption: str) -> dict:
    # 1. Extraer Lugar
    lugar_match = re.search(r'(?i)Lugar:\s*(.*)', caption)
    lugar = lugar_match.group(1).strip() if lugar_match else 'A definir'
    
    # 1b. Extraer Municipio
    municipio_match = re.search(r'(?i)Municipio:\s*(.*)', caption)
    municipio_extraido = municipio_match.group(1).strip() if municipio_match else None
    
    # Concatenar municipio al lugar si existe
    if municipio_extraido and municipio_extraido.lower() not in lugar.lower():
        lugar = f"{municipio_extraido} - {lugar}"
    
    # 2. Extraer Fecha
    fecha_match = re.search(r'(\d{2}/\d{2}/\d{2,4})', caption)
    fecha = fecha_match.group(1) if fecha_match else None
    if fecha:
        # Convertir DD/MM/YYYY a YYYY-MM-DD para postgres (si es YY asume 2000+)
        try:
            if len(fecha.strip()) == 8: # DD/MM/YY
                d = datetime.strptime(fecha, "%d/%m/%y")
            else:
                d = datetime.strptime(fecha, "%d/%m/%Y")
            fecha = d.strftime("%Y-%m-%d")
        except ValueError:
            pass # Si falla el parseo se guarda como string y que falle postgres o dejarlo
            
    # 3. Extraer Hora
    hora_match = re.search(r'(\d{2}:\d{2})', caption)
    hora = hora_match.group(1) if hora_match else None
    if hora:
        try:
            hora = datetime.strptime(hora, "%H:%M").time().strftime("%H:%M:%S")
        except ValueError:
            pass

    # 4. Limpieza (Eliminar hashtags y líneas de etiquetas técnicas como "Lugar: ...")
    clean_text = re.sub(r'#\w+', '', caption) # Elimina hashtags
    clean_text = re.sub(r'(?i)Lugar:\s*.*', '', clean_text) # Elimina linea Lugar
    clean_text = re.sub(r'(?i)Municipio:\s*.*', '', clean_text) # Elimina linea Municipio
    clean_text = re.sub(r'(\d{2}/\d{2}/\d{2,4})', '', clean_text) # Elimina fechas
    clean_text = re.sub(r'(\d{2}:\d{2})', '', clean_text) # Elimina horas
    clean_text = re.sub(r'\n\s*\n', '\n', clean_text).strip() # Limpiar lineas vacias
    
    # Asumimos que la primera linea que queda es el título si existe
    lineas = clean_text.split('\n')
    titulo = lineas[0].strip() if lineas and lineas[0].strip() else "Evento Municipal"
    
    return {
        "lugar": lugar,
        "fecha_evento": fecha,
        "hora_evento": hora,
        "descripcion_limpia": clean_text,
        "titulo": titulo
    }

def procesar_imagen_evento(media_url: str, post_id: str) -> Optional[str]:
    try:
        if not media_url:
            return None
            
        r = requests.get(media_url, stream=True, timeout=10)
        r.raise_for_status()
        
        # Guardar en memoria y subir a supabase storage
        file_bytes = r.content
        filename = f"{post_id}_{uuid4().hex[:8]}.jpg" # Asumimos jpg de IG
        
        # Subir al bucket 'imagenes-eventos'. 
        # Asegurarse que el bucket existe y es público en Supabase.
        res = supabase.storage.from_("imagenes-eventos").upload(
            file=file_bytes,
            path=filename,
            file_options={"content-type": "image/jpeg"}
        )
        
        # Obtener URL publica
        url_publica = supabase.storage.from_("imagenes-eventos").get_public_url(filename)
        return url_publica
    except Exception as e:
        logger.error(f"Error procesando imagen del evento para post {post_id}: {str(e)}")
        # Si falla la imagen, no fallamos todo el proceso, retornamos la URL original temporal o None
        return media_url 


# 3. ENDPOINT REGISTER (Integrado con Supabase Auth y Public Profiles)
@app.post("/api/register", status_code=status.HTTP_201_CREATED)
@limiter.limit("10/minute")
def register(socio: RegisterRequest, request: Request, background_tasks: BackgroundTasks):
    try:
        # 3.A: Validar Rol
        rol_asignado = socio.rol.upper() if socio.rol else "SOCIO"
        if rol_asignado not in ["SOCIO", "COMERCIO", "CAMARA"]:
            rol_asignado = "SOCIO" # Fallback de seguridad

        # 3.B: Crear usuario en Supabase Auth con la contraseña elegida por el usuario
        user_password = socio.password if socio.password else "socio1234"
        default_passwords_list = ["comercio1234", "socio1234", "socio123", "camara1234"]
        user_password_was_set = socio.password is not None and len(socio.password) >= 8 and (socio.password not in default_passwords_list)
        
        auth_response = supabase.auth.admin.create_user({
            "email": socio.email,
            "password": user_password,
            "email_confirm": True
        })
        
        user_id = auth_response.user.id
        
        # 3.C: Insertar en la tabla public.profiles (El DNI debe ser UNIQUE segun esquema)
        profile_data = {
            "id": user_id,
            "nombre_apellido": socio.nombre_apellido,
            "dni": socio.dni_cuit,
            "email": socio.email,
            "telefono": socio.telefono,
            "rol": rol_asignado,
            "estado": "PENDIENTE", 
            "municipio": socio.municipio,
            "direccion": socio.direccion,
            "rubro": socio.rubro,
            "es_profesional": socio.es_profesional,
            "password_changed": user_password_was_set,  # Solo True si NO es una de las default
        }
        
        # Inserción en tabla profiles - con rollback al auth si falla
        try:
            supabase.table("profiles").insert(profile_data).execute()
            
            # 3.D: Si es COMERCIO, insertar en la tabla comercios
            if rol_asignado == "COMERCIO":
                commerce_data = {
                    "id": user_id,
                    "nombre_comercio": socio.nombre_apellido,
                    "cuit": socio.dni_cuit,
                    "rubro": socio.rubro,
                    "direccion": socio.direccion
                }
                supabase.table("comercios").insert(commerce_data).execute()
                
            # 3.E: Si es CAMARA, insertar en la tabla camaras
            elif rol_asignado == "CAMARA":
                # Al llegar desde el front como 'CAMARA', esperamos que use los campos correspondientes
                # Mapeamos los campos del RegisterRequest para la Cámara
                # Como el request actualmente define: nombre_apellido, dni_cuit, municipio, email, telefono
                camara_data = {
                    "id": user_id,
                    "denominacion": socio.nombre_apellido, # El form del frente envía denominación aquí
                    "cuit": socio.dni_cuit,
                    "municipio": socio.municipio or "",
                    "provincia": socio.direccion or "", # Usamos direccion para la provincia (según el mapping esperado o adaptamos)
                    "responsable_nombre": socio.rubro or "", # Usamos rubro para el responsable (según como lo manda el front, revisaremos Registro.tsx)
                    "email": socio.email,
                    "telefono": socio.telefono
                }
                supabase.table("camaras").insert(camara_data).execute()

        except Exception as profile_err:
            # Rollback: eliminar usuario de Auth para que pueda reintentar el registro
            try:
                supabase.auth.admin.delete_user(user_id)
            except:
                pass
            raise profile_err
        
        # Auditoría
        background_tasks.add_task(registrar_auditoria, 
            usuario_id=user_id,
            email_usuario=socio.email,
            rol_usuario=rol_asignado,
            accion="CREATE",
            tabla="profiles",
            registro_id=user_id,
            datos_anteriores=None,
            datos_nuevos=profile_data,
            modulo="Registro Cuentas",
            request=request
        )
        
        return {
            "message": f"{rol_asignado.capitalize()} registrado correctamente. Pendiente de aprobación por Admin.", 
            "socio": profile_data
        }
        
    except Exception as e:
        err_msg = str(e).lower()
        # Identificamos el tipo de error (usualmente de Supabase Auth o restricciones Unique)
        if "user already registered" in err_msg or "already exists" in err_msg and "email" in err_msg:
            friendly_detail = "El correo electrónico indicado ya se encuentra registrado."
        elif "duplicate key value" in err_msg and "dni" in err_msg:
            friendly_detail = "El DNI/CUIT ingresado ya se encuentra registrado en el sistema. Por favor verificá tus datos o iniciá sesión."
        elif "duplicate key value" in err_msg:
            friendly_detail = "Algunos de los datos brindados ya se encuentran registrados."
        else:
            friendly_detail = f"Error al procesar el registro: Verifique sus datos y vuelva a intentar."

        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=friendly_detail
        )


# 4. ENDPOINT LOGIN (Diferenciación de DNI y Email con Auth en Supabase)
@app.post("/api/login")
@limiter.limit("5/minute")
def login(credentials: LoginRequest, request: Request):
    identificador_limpio = credentials.identificador.strip()
    password = credentials.password
    
    print(f"Login attempt for: {identificador_limpio}")
    # 4.A IDENTIFICAR TIPO DE INGRESO
    tipo_identificacion = "unknown"
    login_email = None
    
    if "@" in identificador_limpio:
        tipo_identificacion = "email"
        login_email = identificador_limpio
    elif identificador_limpio.isdigit():
        tipo_identificacion = "dni" # Numerico es DNI o CUIT
        
        # Si es DNI, necesitamos buscar el email en la tabla public.profiles
        try:
            response = supabase.table("profiles").select("email").eq("dni", identificador_limpio).execute()
            if not response.data or len(response.data) == 0:
                raise HTTPException(status_code=401, detail="Credenciales inválidas (DNI no encontrado)")
            login_email = response.data[0]["email"]
        except Exception as e:
            if isinstance(e, HTTPException): raise e
            raise HTTPException(status_code=500, detail="Error consultando DNI")
    else:
        tipo_identificacion = "username" # Alfanumérico se asume como nombre de usuario
        try:
            response = supabase.table("profiles").select("email").eq("username", identificador_limpio).execute()
            if not response.data or len(response.data) == 0:
                raise HTTPException(status_code=401, detail="Credenciales inválidas (Usuario no encontrado)")
            login_email = response.data[0]["email"]
        except Exception as e:
            if isinstance(e, HTTPException): raise e
            raise HTTPException(status_code=500, detail="Error consultando Usuario")
            
    if not login_email:
        raise HTTPException(status_code=400, detail="Identificador no válido")

    print(f"Login email resolved: {login_email}")
    # 4.B: AUTENTICAR CON SUPABASE AUTH
    try:
        print("Authenticating with Supabase Auth...")
        # Hacemos signIn para generar y verificar token/pass.
        # IMPORTANTE: Usamos un cliente local para no sobreescribir la sesión del cliente global 'supabase' (Service Role)
        auth_client = create_client(SUPABASE_URL, SUPABASE_KEY)
        auth_response = auth_client.auth.sign_in_with_password({
            "email": login_email,
            "password": password
        })
        
        session = auth_response.session
        user = auth_response.user
        print("Auth success, fetching profile...")
        # 4.C: RECUPERAR PERFIL Y ESTADO usando el cliente global con permisos de Admin
        profile_res = supabase.table("profiles").select("*").eq("id", user.id).execute()
        print("Profile fetched.")
        if not profile_res.data:
            raise HTTPException(status_code=500, detail="Perfil no encontrado en base de datos")
            
        profile = profile_res.data[0]
        
        # Validar si está pendiente o suspendido (Bloquear aquí en el login)
        if profile["estado"] not in ["APROBADO", "RESTRINGIDO"]:
            raise HTTPException(status_code=403, detail=f"Su usuario se encuentra {profile['estado']}. Contacte a la Administración.")

        # Validación: PRIMER LOGIN OBLIGATORIO SI USA PASS POR DEFECTO O FUE RESTABLECIDA POR ADMIN
        necesita_cambio_password = False
        default_passwords = ["comercio1234", "socio1234", "socio123", "SRNC2026!", "Admin1234", "x3n3iz3@41"]
        if password in default_passwords or profile.get("password_changed") is False:
            necesita_cambio_password = True
            
        # Auditoría de Login para Administradores
        # Verificamos si tiene rol SUPERADMIN o ADMINISTRADOR (o si su rol base es ADMIN)
        roles_res = supabase.table("user_roles").select("roles(nombre)").eq("user_id", user.id).execute()
        user_roles_list = []
        if roles_res.data:
            user_roles_list = [item["roles"]["nombre"] for item in roles_res.data if item.get("roles")]
            
        profile["user_roles"] = user_roles_list
        
        # Si es admin de algún tipo, registrar el acceso
        if profile.get("rol") == "ADMIN" or "SUPERADMIN" in user_roles_list or "ADMINISTRADOR" in user_roles_list:
            background_tasks.add_task(registrar_auditoria, 
                usuario_id=user.id,
                email_usuario=login_email,
                rol_usuario=" | ".join(user_roles_list) if user_roles_list else profile.get("rol"),
                accion="LOGIN_ADMIN",
                tabla="auth.users",
                registro_id=user.id,
                datos_anteriores=None,
                datos_nuevos={"metodo": tipo_identificacion, "roles": user_roles_list},
                modulo="Autenticación Administrativa",
                request=request
            )

        return {
            "message": "Login exitoso",
            "tipo_identificacion_detectado": tipo_identificacion,
            "necesita_cambio_password": necesita_cambio_password,
            "socio": profile,
            "token": session.access_token, # JWT real de Supabase devuelto al front
            "refresh_token": session.refresh_token # Para renovación automática del token
        }
        
    except Exception as e:
        # Auth api error format fallback
        if "Invalid login credentials" in str(e) or getattr(e, "status_code", 400) == 400:
             raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Credenciales inválidas"
            )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error en login: {str(e)}"
        )

from fastapi import Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

security = HTTPBearer()

def get_current_superadmin(credentials: HTTPAuthorizationCredentials = Depends(security)):
    token = credentials.credentials
    try:
        user_res = supabase.auth.get_user(token)
        if not user_res or not user_res.user:
            raise HTTPException(status_code=401, detail="Token inválido")
            
        roles_res = supabase.table("user_roles").select("roles(nombre)").eq("user_id", user_res.user.id).execute()
        user_roles = [r["roles"]["nombre"] for r in roles_res.data if r.get("roles")] if roles_res.data else []
        
        if "SUPERADMIN" not in user_roles:
            raise HTTPException(status_code=403, detail="Requiere rol de SUPERADMIN")
            
        return user_res.user
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=401, detail="Error verificando permisos")

def get_current_admin(credentials: HTTPAuthorizationCredentials = Depends(security)):
    token = credentials.credentials
    try:
        user_res = supabase.auth.get_user(token)
        if not user_res or not user_res.user:
            raise HTTPException(status_code=401, detail="Token inválido")
            
        profile_res = supabase.table("profiles").select("rol").eq("id", user_res.user.id).execute()
        roles_res = supabase.table("user_roles").select("roles(nombre)").eq("user_id", user_res.user.id).execute()
        user_roles = [r["roles"]["nombre"] for r in roles_res.data if r.get("roles")] if roles_res.data else []
        
        has_admin_role = "SUPERADMIN" in user_roles or "ADMINISTRADOR" in user_roles or (profile_res.data and profile_res.data[0].get("rol") == "ADMIN")
        
        if not has_admin_role:
            raise HTTPException(status_code=403, detail="Requiere rol de Administrador")
            
        return user_res.user
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=401, detail="Error verificando permisos")

async def get_current_admin_optional(request: Request):
    """
    Versión opcional del middleware de admin. 
    Si hay token válido de admin, lo retorna. Si no, retorna None sin fallar.
    Útil para endpoints mixtos (públicos/cron vs admin manual).
    """
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        return None
    
    token = auth_header.split(" ")[1]
    try:
        user_res = supabase.auth.get_user(token)
        if not user_res or not user_res.user:
            return None
            
        profile_res = supabase.table("profiles").select("rol").eq("id", user_res.user.id).execute()
        roles_res = supabase.table("user_roles").select("roles(nombre)").eq("user_id", user_res.user.id).execute()
        user_roles = [r["roles"]["nombre"] for r in roles_res.data if r.get("roles")] if roles_res.data else []
        
        has_admin_role = "SUPERADMIN" in user_roles or "ADMINISTRADOR" in user_roles or (profile_res.data and profile_res.data[0].get("rol") == "ADMIN")
        
        if not has_admin_role:
            return None
            
        return user_res.user
    except Exception:
        return None

def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    token = credentials.credentials
    try:
        user_res = supabase.auth.get_user(token)
        if not user_res or not user_res.user:
            raise HTTPException(status_code=401, detail="Token inválido")
        return user_res.user
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        err_msg = str(e).lower()
        print(f"Auth error in get_current_user: {err_msg}")
        # Detectar token expirado según mensaje común de GoTrue/Supabase
        if "expired" in err_msg:
            raise HTTPException(status_code=401, detail="Token expirado")
        raise HTTPException(status_code=401, detail=f"No autorizado: {str(e)}")

def get_current_admin_or_camara(credentials: HTTPAuthorizationCredentials = Depends(security)):
    token = credentials.credentials
    try:
        user_res = supabase.auth.get_user(token)
        if not user_res or not user_res.user:
            raise HTTPException(status_code=401, detail="Token inválido")
            
        profile_res = supabase.table("profiles").select("rol", "estado").eq("id", user_res.user.id).execute()
        roles_res = supabase.table("user_roles").select("roles(nombre)").eq("user_id", user_res.user.id).execute()
        
        if not profile_res.data:
            raise HTTPException(status_code=403, detail="Perfil no encontrado")
            
        rol = profile_res.data[0].get("rol")
        estado = profile_res.data[0].get("estado")
        user_roles = [r["roles"]["nombre"] for r in roles_res.data if r.get("roles")] if roles_res.data else []
        has_admin_role = "SUPERADMIN" in user_roles or "ADMINISTRADOR" in user_roles or rol == "ADMIN"
        
        if not (has_admin_role or rol == "CAMARA") or estado != "APROBADO":
            raise HTTPException(status_code=403, detail="Requiere rol de Administrador o Cámara Aprobada")
            
        return user_res.user
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=401, detail="Error verificando permisos")

# 4.4 LISTADO DE MUNICIPIOS FIJOS
@app.get("/api/municipios")
def get_municipios():
    # Lista predeterminada y fija de cámaras de municipios sugerida
    municipios = [
        {"id": "ctes-capital", "nombre": "Corrientes Capital"},
        {"id": "goya", "nombre": "Goya"},
        {"id": "paso-de-los-libres", "nombre": "Paso de los Libres"},
        {"id": "curuzu-cuatia", "nombre": "Curuzú Cuatiá"},
        {"id": "mercedes", "nombre": "Mercedes"},
        {"id": "bella-vista", "nombre": "Bella Vista"},
        {"id": "ituzaingo", "nombre": "Ituzaingó"},
        {"id": "gobernador-virasoro", "nombre": "Gobernador Virasoro"},
        {"id": "esquina", "nombre": "Esquina"},
        {"id": "monte-caseros", "nombre": "Monte Caseros"},
        {"id": "empedrado", "nombre": "Empedrado"},
        {"id": "el-sombrero", "nombre": "El Sombrero"},
        {"id": "itati", "nombre": "Itatí"},
        {"id": "santa-ana", "nombre": "Santa Ana"},
        {"id": "san-cosme", "nombre": "San Cosme"}
    ]
    return {"municipios": municipios}

# ── ENDPOINT PÚBLICO: listar comercios adheridos ─────────────────────────────
class ChangePasswordRequest(BaseModel):
    new_password: str

@app.get("/api/comercios")
def listar_comercios(rubro: Optional[str] = None, municipio: Optional[str] = None):
    """Retorna la lista de comercios aprobados, filtrable por rubro o municipio."""
    try:
        query = supabase.table("profiles") \
            .select("id, nombre_apellido, rubro, municipio, telefono, email") \
            .eq("rol", "COMERCIO") \
            .eq("estado", "APROBADO") \
            .order("nombre_apellido")
        if rubro:
            query = query.eq("rubro", rubro)
        if municipio:
            query = query.eq("municipio", municipio)
        result = query.execute()
        return {"comercios": result.data}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ── ENDPOINT PARA VALIDAR CARNET DE SOCIO DESDE QR ────────────────────────────
@app.get("/api/valida-socio/{socio_id}")
def valida_socio(socio_id: str):
    """
    Recibe el ID del socio (codificado en el QR) y devuelve su estado de validación.
    Los Comercios llamarán a este endpoint cuando escaneen el Carnet del Socio.
    """
    try:
        # Buscamos al perfil y opcionalmente a su titular
        result = supabase.table("profiles").select("id, nombre_apellido, dni, rol, estado, municipio, titular_id, tipo_vinculo, perfiles_titulares:profiles!titular_id(nombre_apellido, estado)").eq("id", socio_id).execute()
        
        if not result.data:
            raise HTTPException(status_code=404, detail="El código QR no pertenece a un usuario registrado válido.")
            
        perfil = result.data[0]
        
        # Titular o empleado?
        if perfil["rol"] not in ["SOCIO", "COMERCIO"]:
            raise HTTPException(status_code=400, detail="El código QR no pertenece a un Socio o Comercio válido.")
            
        es_activo = (perfil["estado"] == "APROBADO")
        mensaje = "✅ Socio Activo. Apto para recibir beneficios." if es_activo else f"❌ Usuario inactivo o estado pendiente ({perfil['estado']})."
        
        titular = perfil.get("perfiles_titulares")
        if titular:
            titular_valido = titular.get("estado") == "APROBADO"
            if not titular_valido:
                es_activo = False
                mensaje = f"❌ El titular de este usuario ({titular.get('nombre_apellido')}) está en estado {titular.get('estado')}."
            else:
                vinculo = perfil.get("tipo_vinculo", "Adherente").capitalize()
                mensaje = f"✅ {vinculo} Activo. Titular: {titular.get('nombre_apellido')}."

        return {
            "valido": es_activo,
            "socio": {
                "id": perfil["id"],
                "nombre_apellido": perfil["nombre_apellido"],
                "dni": perfil["dni"],
                "estado": perfil["estado"],
                "municipio": perfil["municipio"],
                "rol": perfil["rol"],
                "tipo_vinculo": perfil.get("tipo_vinculo"),
                "titular_id": perfil.get("titular_id")
            },
            "mensaje": mensaje
        }
        
    except Exception as e:
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail=f"Error al validar socio: {str(e)}")


@app.post("/api/change-password")
def change_password(req: ChangePasswordRequest, request: Request,background_tasks: BackgroundTasks,  current_user  = Depends(get_current_user)):
    try:
        if len(req.new_password) < 6:
            raise HTTPException(status_code=400, detail="La contraseña debe tener al menos 6 caracteres")
            
        # Actualizar contraseña en Auth usando modo Admin ya que tenemos la Service Role key
        supabase.auth.admin.update_user_by_id(
            current_user.id,
            {"password": req.new_password}
        )
        
        # Marcar en profile como password_changed = True
        supabase.table("profiles").update({"password_changed": True}).eq("id", current_user.id).execute()
        
        # Auditoría
        background_tasks.add_task(registrar_auditoria, 
            usuario_id=current_user.id,
            email_usuario=current_user.email,
            rol_usuario=None,
            accion="UPDATE",
            tabla="profiles",
            registro_id=current_user.id,
            datos_anteriores=None,
            datos_nuevos={"password_changed": True},
            modulo="Seguridad",
            request=request
        )
        
        return {"message": "Contraseña actualizada correctamente"}
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=500, detail=f"Error actualizando la contraseña: {str(e)}")

# ── GESTIÓN DE ADMINISTRADORES (SOLO SUPERADMIN) ─────────────────────────
@app.get("/api/admin/administradores")
def get_all_administradores(superadmin_user = Depends(get_current_superadmin)):
    try:
        # Obtenemos usuarios que tengan rol en user_roles con nombre 'SUPERADMIN' o 'ADMINISTRADOR'
        # Hacemos join directo usando la relación en supabase
        res = supabase.table("user_roles").select("user_id, roles!inner(nombre), profiles!inner(id, username, email, nombre_apellido, dni, rol, estado, created_at)").in_("roles.nombre", ["SUPERADMIN", "ADMINISTRADOR"]).execute()
        
        # Agrupar por usuario ya que pueden tener multipes roles en user_roles si algo fallo, pero solo nos importa mostrar uno o la lista
        users = {}
        for item in (res.data or []):
            uid = item["user_id"]
            if uid not in users:
                users[uid] = item["profiles"]
                users[uid]["user_roles"] = []
            
            users[uid]["user_roles"].append(item["roles"]["nombre"])
            
        return {"administradores": list(users.values())}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/admin/administradores")
def create_administrador(
    req: CreateAdminRequest, 
    request: Request, 
    background_tasks: BackgroundTasks, 
    superadmin_user = Depends(get_current_superadmin)
):
    try:
        rol_asignar = req.rol.upper()
        if rol_asignar not in ["SUPERADMIN", "ADMINISTRADOR"]:
            raise HTTPException(status_code=400, detail="Rol inválido")
            
        # Get Role IDs
        roles_res = supabase.table("roles").select("*").execute()
        roles_map = {r["nombre"]: r["id"] for r in roles_res.data}
        
        # Validar Username unico
        existing = supabase.table("profiles").select("id").eq("username", req.username).execute()
        if existing.data:
            raise HTTPException(status_code=400, detail="El nombre de usuario ya existe")
            
        # 1. Crear en Auth
        try:
            auth_res = supabase.auth.admin.create_user({
                "email": req.email,
                "password": req.password,
                "email_confirm": True
            })
            user_id = auth_res.user.id
        except Exception as e:
            if "already registered" in str(e).lower() or "already exists" in str(e).lower():
                raise HTTPException(status_code=400, detail="El correo electrónico ya está registrado")
            raise HTTPException(status_code=500, detail=f"Error Auth: {str(e)}")
            
        # 2. Crear Perfil
        profile_data = {
            "id": user_id,
            "username": req.username,
            "dni": req.dni,
            "email": req.email,
            "nombre_apellido": req.nombre_apellido,
            "rol": "ADMIN", # Rol base retrocompatible
            "estado": "APROBADO",
            "password_changed": True
        }
        
        try:
            supabase.table("profiles").insert(profile_data).execute()
        except Exception as e:
            supabase.auth.admin.delete_user(user_id)
            raise HTTPException(status_code=500, detail=f"Error creando perfil: {str(e)}")
            
        # 3. Asignar Roles
        try:
            # Rol admin solicitado
            supabase.table("user_roles").insert({"user_id": user_id, "role_id": roles_map[rol_asignar]}).execute()
            # Todos los admins también son SOCIOS
            supabase.table("user_roles").insert({"user_id": user_id, "role_id": roles_map["SOCIO"]}).execute()
        except:
            pass # Si falla no revertimos todo, quizas solo el rol. Lo dejamos así.
            
        background_tasks.add_task(registrar_auditoria, 
            usuario_id=superadmin_user.id,
            email_usuario=superadmin_user.email,
            rol_usuario="SUPERADMIN",
            accion="CREATE_ADMIN",
            tabla="auth.users",
            registro_id=user_id,
            datos_anteriores=None,
            datos_nuevos=profile_data,
            modulo="Gestión de Administradores",
            request=request
        )
            
        return {"message": "Administrador creado exitosamente"}
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.put("/api/admin/administradores/{user_id}/role")
def update_administrador_role(
    user_id: str,
    req: UpdateAdminRoleRequest,
    request: Request,
    background_tasks: BackgroundTasks,
    superadmin_user = Depends(get_current_superadmin)
):
    try:
        if user_id == superadmin_user.id and req.rol.upper() != "SUPERADMIN":
            raise HTTPException(status_code=400, detail="No puedes degradar tu propio rol de Superadmin")

        rol_asignar = req.rol.upper()
        if rol_asignar not in ["SUPERADMIN", "ADMINISTRADOR"]:
            raise HTTPException(status_code=400, detail="Rol inválido")

        # Get Role IDs
        roles_res = supabase.table("roles").select("*").execute()
        roles_map = {r["nombre"]: r["id"] for r in roles_res.data}
        target_role_id = roles_map.get(rol_asignar)
        if not target_role_id:
            raise HTTPException(status_code=500, detail="Rol no encontrado en la base de datos")

        # Fetch current roles for audit and validation
        current_user_roles_res = supabase.table("user_roles").select("roles(nombre), role_id").eq("user_id", user_id).in_("roles.nombre", ["SUPERADMIN", "ADMINISTRADOR"]).execute()
        current_admin_roles = [r["roles"]["nombre"] for r in current_user_roles_res.data if r.get("roles")]
        current_admin_role_ids = [r["role_id"] for r in current_user_roles_res.data]

        if not current_admin_roles:
            raise HTTPException(status_code=404, detail="Usuario no es un administrador existente")

        # Determine previous role for audit
        previous_role = "ADMINISTRADOR" if "ADMINISTRADOR" in current_admin_roles else "SUPERADMIN"

        # Remove existing admin roles
        for role_id_to_remove in current_admin_role_ids:
            supabase.table("user_roles").delete().eq("user_id", user_id).eq("role_id", role_id_to_remove).execute()

        # Assign new role
        supabase.table("user_roles").insert({"user_id": user_id, "role_id": target_role_id}).execute()

        background_tasks.add_task(registrar_auditoria,
            usuario_id=superadmin_user.id,
            email_usuario=superadmin_user.email,
            rol_usuario="SUPERADMIN",
            accion="UPDATE_ADMIN_ROLE",
            tabla="user_roles",
            registro_id=user_id,
            datos_anteriores={"rol": previous_role},
            datos_nuevos={"rol": rol_asignar},
            modulo="Gestión de Administradores",
            request=request
        )

        return {"message": f"Rol de administrador actualizado a {rol_asignar}"}
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/api/admin/administradores/{user_id}")
def delete_administrador(
    user_id: str, 
    request: Request, 
    background_tasks: BackgroundTasks, 
    superadmin_user = Depends(get_current_superadmin)
):
    try:
        # Prevent self-deletion
        if user_id == superadmin_user.id:
            raise HTTPException(status_code=400, detail="No puede eliminarse a sí mismo")
            
        # Fetch profile for audit
        prof_res = supabase.table("profiles").select("*").eq("id", user_id).execute()
        if not prof_res.data:
            raise HTTPException(status_code=404, detail="Administrador no encontrado")
            
        # Delete from Auth (Cascade)
        supabase.auth.admin.delete_user(user_id)
        
        background_tasks.add_task(registrar_auditoria, 
            usuario_id=superadmin_user.id,
            email_usuario=superadmin_user.email,
            rol_usuario="SUPERADMIN",
            accion="DELETE_ADMIN",
            tabla="auth.users",
            registro_id=user_id,
            datos_anteriores=prof_res.data[0],
            datos_nuevos=None,
            modulo="Gestión de Administradores",
            request=request
        )
        return {"message": "Administrador eliminado permanentemente"}
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# 5. ENDPOINT ADMIN: LISTAR PENDIENTES
@app.get("/api/admin/users/pending")
def get_pending_users(limit: int = Query(default=50, le=100), offset: int = Query(default=0, ge=0), admin_user = Depends(get_current_admin)):
    try:
        response = supabase.table("profiles").select("*").eq("estado", "PENDIENTE").range(offset, offset + limit - 1).execute()
        return {"users": response.data}
    except Exception as e:
         raise HTTPException(status_code=500, detail=str(e))

# 6. ENDPOINTS ADMIN: APROBAR / RECHAZAR USUARIO
@app.post("/api/admin/users/{user_id}/approve")
def approve_user(user_id: str, request: Request,background_tasks: BackgroundTasks,  admin_user  = Depends(get_current_admin)):
    try:
        # Validar UUID para prevenir errores de base de datos
        try:
            uuid.UUID(user_id)
        except ValueError:
            raise HTTPException(status_code=400, detail="ID de usuario inválido (No es UUID)")

        res = supabase.table("profiles").update({"estado": "APROBADO"}).eq("id", user_id).execute()
        if not res.data:
            raise HTTPException(status_code=404, detail="Usuario no encontrado")
            
        background_tasks.add_task(registrar_auditoria, 
            usuario_id=admin_user.id,
            email_usuario=admin_user.email,
            rol_usuario="ADMIN",
            accion="APPROVE",
            tabla="profiles",
            registro_id=user_id,
            datos_anteriores={"estado": "PENDIENTE"},
            datos_nuevos={"estado": "APROBADO"},
            modulo="Gestión Usuarios",
            request=request
        )
        return {"message": "Usuario aprobado correctamente"}
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=500, detail=f"Error al aprobar: {str(e)}")

@app.post("/api/admin/users/{user_id}/reject")
def reject_user(user_id: str, request: Request,background_tasks: BackgroundTasks,  admin_user  = Depends(get_current_admin)):
    try:
        # Validar UUID para prevenir errores de base de datos
        try:
            uuid.UUID(user_id)
        except ValueError:
            raise HTTPException(status_code=400, detail="ID de usuario inválido (No es UUID)")

        res = supabase.table("profiles").update({"estado": "RECHAZADO"}).eq("id", user_id).execute()
        if not res.data:
            raise HTTPException(status_code=404, detail="Usuario no encontrado")
            
        background_tasks.add_task(registrar_auditoria, 
            usuario_id=admin_user.id,
            email_usuario=admin_user.email,
            rol_usuario="ADMIN",
            accion="REJECT",
            tabla="profiles",
            registro_id=user_id,
            datos_anteriores={"estado": "PENDIENTE"},
            datos_nuevos={"estado": "RECHAZADO"},
            modulo="Gestión Usuarios",
            request=request
        )
        return {"message": "Usuario rechazado correctamente"}
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=500, detail=f"Error al rechazar: {str(e)}")

# 6.B ENDPOINTS ADMIN OPTIMIZADOS (SPEC)

@app.get("/api/admin/users")
def get_all_users(limit: int = Query(default=50, le=100), offset: int = Query(default=0, ge=0), admin_user = Depends(get_current_admin)):
    """Retorna todos los usuarios del sistema para la tabla de gestión"""
    try:
        response = supabase.table("profiles").select("*").order("created_at", desc=True).range(offset, offset + limit - 1).execute()
        return {"users": response.data}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

class UpdateUserStatusRequest(BaseModel):
    estado: str # "APROBADO" | "SUSPENDIDO" | "PENDIENTE" | "RECHAZADO"

@app.put("/api/admin/users/{user_id}/status")
def update_user_status(user_id: str, req: UpdateUserStatusRequest, request: Request,background_tasks: BackgroundTasks,  admin_user  = Depends(get_current_admin)):
    """Suspende o reactiva un usuario"""
    try:
        # Validar UUID para prevenir errores de base de datos
        try:
            uuid.UUID(user_id)
        except ValueError:
            raise HTTPException(status_code=400, detail="ID de usuario inválido formatualmente (No es UUID)")

        perfil_ant = supabase.table("profiles").select("estado").eq("id", user_id).execute()
        datos_anteriores = perfil_ant.data[0] if perfil_ant.data else None
        
        res = supabase.table("profiles").update({"estado": req.estado}).eq("id", user_id).execute()
        if not res.data:
            raise HTTPException(status_code=404, detail="Usuario no encontrado")
            
        background_tasks.add_task(registrar_auditoria, 
            usuario_id=admin_user.id,
            email_usuario=admin_user.email,
            rol_usuario="ADMIN",
            accion="UPDATE",
            tabla="profiles",
            registro_id=user_id,
            datos_anteriores=datos_anteriores,
            datos_nuevos={"estado": req.estado},
            modulo="Gestión Usuarios",
            request=request
        )
        return {"message": f"Estado actualizado a {req.estado}", "user": res.data[0]}
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=500, detail=f"Error al actualizar estado: {str(e)}")

class UpdateUserRequest(BaseModel):
    nombre_apellido: Optional[str] = None
    telefono: Optional[str] = None
    municipio: Optional[str] = None
    rubro: Optional[str] = None
    email: Optional[str] = None

@app.put("/api/admin/users/{user_id}")
def update_user_details(user_id: str, req: UpdateUserRequest, request: Request,background_tasks: BackgroundTasks,  admin_user  = Depends(get_current_admin)):
    """Edita información básica del perfil desde el dashboard admin"""
    try:
        # Validar UUID para prevenir errores de base de datos
        try:
            uuid.UUID(user_id)
        except ValueError:
            raise HTTPException(status_code=400, detail="ID de usuario inválido (No es UUID)")

        update_data = req.dict(exclude_unset=True)
        if not update_data:
            return {"message": "Sin cambios"}
            
        perfil_ant = supabase.table("profiles").select("*").eq("id", user_id).execute()
        datos_anteriores = perfil_ant.data[0] if perfil_ant.data else None
            
        res = supabase.table("profiles").update(update_data).eq("id", user_id).execute()
        if not res.data:
            raise HTTPException(status_code=404, detail="Usuario no encontrado")
            
        background_tasks.add_task(registrar_auditoria, 
            usuario_id=admin_user.id,
            email_usuario=admin_user.email,
            rol_usuario="ADMIN",
            accion="UPDATE",
            tabla="profiles",
            registro_id=user_id,
            datos_anteriores=datos_anteriores,
            datos_nuevos=update_data,
            modulo="Gestión Usuarios",
            request=request
        )
        return {"message": "Usuario actualizado", "user": res.data[0]}
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=500, detail=f"Error al editar usuario: {str(e)}")

@app.delete("/api/admin/users/{user_id}")
def delete_user(user_id: str, request: Request, background_tasks: BackgroundTasks, admin_user = Depends(get_current_admin)):
    """Elimina un usuario (y su perfil asociado) desde el dashboard admin"""
    try:
        # Validar UUID
        try:
            uuid.UUID(user_id)
        except ValueError:
            raise HTTPException(status_code=400, detail="ID de usuario inválido (No es UUID)")

        if user_id == admin_user.id:
            raise HTTPException(status_code=400, detail="No puedes eliminar tu propia cuenta")
            
        perfil_ant = supabase.table("profiles").select("*").eq("id", user_id).execute()
        datos_anteriores = perfil_ant.data[0] if perfil_ant.data else None
        
        # Eliminar el usuario en Supabase Auth
        # Esto debería disparar la eliminación en cascada si la base de datos está configurada así.
        # Si no, de todas formas lo borramos de Auth para revocar acceso.
        supabase.auth.admin.delete_user(user_id)
        
        # Intentamos borrar el profile explícitamente por si no hay On Delete Cascade. 
        # Si falla porque no existe (ya se borró por cascada), lo ignoramos.
        try:
            supabase.table("profiles").delete().eq("id", user_id).execute()
        except:
            pass

        background_tasks.add_task(registrar_auditoria, 
            usuario_id=admin_user.id,
            email_usuario=admin_user.email,
            rol_usuario="ADMIN",
            accion="DELETE",
            tabla="auth.users / profiles",
            registro_id=user_id,
            datos_anteriores=datos_anteriores,
            datos_nuevos=None,
            modulo="Gestión Usuarios",
            request=request
        )
        return {"message": "Usuario eliminado correctamente"}
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=500, detail=f"Error al eliminar usuario: {str(e)}")

class ResetPasswordRequest(BaseModel):
    new_password: Optional[str] = "SRNC2026!"

@app.post("/api/admin/users/{user_id}/reset-password")
def reset_user_password(user_id: str, req: ResetPasswordRequest, request: Request, background_tasks: BackgroundTasks, admin_user = Depends(get_current_admin)):
    """Restablece la contraseña de un usuario a un valor por defecto o especificado"""
    try:
        # Validar UUID
        try:
            uuid.UUID(user_id)
        except ValueError:
            raise HTTPException(status_code=400, detail="ID de usuario inválido")

        # Prevenir que un ADMIN restablezca la clave de otro ADMIN (Tenant Security)
        target_profile = supabase.table("profiles").select("rol").eq("id", user_id).execute()
        if target_profile.data and target_profile.data[0].get("rol") == "ADMIN" and admin_user.id != user_id:
            raise HTTPException(status_code=403, detail="No tienes permisos para restablecer la contraseña de otro Administrador.")
            
        new_password = req.new_password if req.new_password else "SRNC2026!"
        
        # Validar longitud mínima de Supabase
        if len(new_password) < 6:
            raise HTTPException(status_code=400, detail="La contraseña debe tener al menos 6 caracteres")
            
        # Actualizar en Auth
        auth_response = supabase.auth.admin.update_user_by_id(user_id, {"password": new_password})
        
        # Actualizar en profiles para forzar el cambio
        supabase.table("profiles").update({"password_changed": False}).eq("id", user_id).execute()
        
        background_tasks.add_task(registrar_auditoria, 
            usuario_id=admin_user.id,
            email_usuario=admin_user.email,
            rol_usuario="ADMIN",
            accion="UPDATE",
            tabla="auth.users (Password)",
            registro_id=user_id,
            datos_anteriores=None,
            datos_nuevos={"password_reset": True},
            modulo="Gestión Usuarios",
            request=request
        )
        return {"message": "Contraseña restablecida correctamente", "temporary_password": new_password}
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=500, detail=f"Error al restablecer contraseña: {str(e)}")


@app.put("/api/camara/comercios/{user_id}")
def update_commerce_by_camara(user_id: str, req: UpdateUserRequest, request: Request,background_tasks: BackgroundTasks,  auth_user  = Depends(get_current_admin_or_camara)):
    """Edita información del comercio vinculada a la cámara."""
    try:
        # Validar UUID para prevenir errores de base de datos
        try:
            uuid.UUID(user_id)
        except ValueError:
            raise HTTPException(status_code=400, detail="ID de usuario inválido formatualmente (No es UUID)")

        check = supabase.table("profiles").select("*").eq("id", user_id).execute()
        if not check.data:
             raise HTTPException(status_code=404, detail="Comercio no encontrado")
        
        perfil = check.data[0]
        if perfil.get("rol") != "COMERCIO":
             raise HTTPException(status_code=403, detail="Solo se pueden editar comercios")
             
        if perfil.get("titular_id") != auth_user.id:
             raise HTTPException(status_code=403, detail="Este comercio no pertenece a su cámara")

        update_data = req.dict(exclude_unset=True)
        if not update_data:
            return {"message": "Sin cambios"}
            
        update_data["estado"] = "PENDIENTE" 
            
        res = supabase.table("profiles").update(update_data).eq("id", user_id).execute()
        
        background_tasks.add_task(registrar_auditoria, 
            usuario_id=auth_user.id,
            email_usuario=auth_user.email,
            rol_usuario="CAMARA",
            accion="UPDATE",
            tabla="profiles",
            registro_id=user_id,
            datos_anteriores=perfil,
            datos_nuevos=update_data,
            modulo="Gestión Comercios",
            request=request
        )
        return {"message": "Datos de comercio actualizados. Pendiente de re-aprobación del Admin.", "user": res.data[0]}
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=500, detail=f"Error al editar comercio: {str(e)}")

@app.get("/api/admin/metrics/overview")
def get_metrics_overview(admin_user = Depends(get_current_admin)):
    """Endpoint para dashboard principal de KPIs"""
    try:
        # Extraer todos los perfiles para procesar metricas en memoria es mas facil por ahora
        # En prod con millones de registros se harian queries SELECT count(*) con raw SQL en rpc()
        res = supabase.table("profiles").select("rol, estado").execute()
        profiles = res.data or []
        
        total_socios = sum(1 for p in profiles if p.get("rol") == "SOCIO" and p.get("estado") == "APROBADO")
        total_comercios = sum(1 for p in profiles if p.get("rol") == "COMERCIO" and p.get("estado") == "APROBADO")
        total_pendientes = sum(1 for p in profiles if p.get("estado") == "PENDIENTE")

        # Conteo de validaciones de pago pendientes 2.0
        pagos_res = supabase.table("pagos_cuotas") \
            .select("id", count="exact") \
            .eq("estado_pago", "PENDIENTE_VALIDACION") \
            .execute()
        validaciones_pendientes = pagos_res.count if pagos_res.count is not None else 0
        
        return {
            "metrics": {
                "total_socios": total_socios,
                "total_comercios": total_comercios,
                "total_pendientes": total_pendientes,
                "validaciones_pendientes": validaciones_pendientes,
                "ingresos_mes": 0 # TODO: Conectar con Stripe/MercadoPago luego
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error cargando métricas: {str(e)}")

@app.get("/api/camara/mis-comercios")
def get_my_dependents(auth_user = Depends(get_current_admin_or_camara)):
    """Retorna los comercios vinculados a la cámara o todos si es admin"""
    try:
        # Extraemos el rol del usuario autenticado de la tabla profiles
        profile_res = supabase.table("profiles").select("rol").eq("id", auth_user.id).execute()
        if not profile_res.data:
            raise HTTPException(status_code=403, detail="Perfil no encontrado")
            
        rol = profile_res.data[0]["rol"]
        
        query = supabase.table("profiles").select("*")
        if rol == "CAMARA":
            query = query.eq("titular_id", auth_user.id).eq("rol", "COMERCIO")
        elif rol == "ADMIN":
            query = query.eq("rol", "COMERCIO")
        
        res = query.execute()
        return {"dependientes": res.data}
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=500, detail=f"Error al obtener dependientes: {str(e)}")

# 7. MODELO Y ENDPOINT ADMIN: CREAR COMERCIO
class ComercioRequest(BaseModel):
    nombre_comercio: str
    cuit: str
    email: EmailStr
    telefono: str
    rubro: str
    direccion: Optional[str] = None

@app.post("/api/admin/comercios", status_code=status.HTTP_201_CREATED)
def create_commerce(comercio: ComercioRequest, request: Request, background_tasks: BackgroundTasks, auth_user = Depends(get_current_admin_or_camara)):
    try:
        # Extraer rol y perfil del usuario autenticado
        profile_res = supabase.table("profiles").select("rol", "municipio").eq("id", auth_user.id).execute()
        if not profile_res.data:
            raise HTTPException(status_code=403, detail="Perfil no encontrado")
        
        user_profile = profile_res.data[0]
        user_rol = user_profile["rol"]
        user_municipio = user_profile["municipio"]

        # Si el usuario es CAMARA, aplicar límites y reglas
        titular_id = None
        final_municipio = None # Se tomará del request si es ADMIN

        if user_rol == "CAMARA":
            # 1. Validar límite de 10 comercios
            count_res = supabase.table("profiles").select("id", count="exact").eq("titular_id", auth_user.id).eq("rol", "COMERCIO").execute()
            if count_res.count is not None and count_res.count >= 10:
                raise HTTPException(status_code=400, detail="Has alcanzado el límite de 10 comercios registrados para tu cámara.")
            
            # 2. El municipio del comercio DEBE ser el mismo de la cámara
            titular_id = auth_user.id
            final_municipio = user_municipio
        else:
            # Si es ADMIN, puede elegir municipio (si viene en el request, aunque el modelo no lo tiene, lo dejamos para el futuro o usamos rubro temporalmente si se mapeó así)
            # Por ahora, si es ADMIN, titular_id queda en None.
            pass

        default_password = "comercio1234" 
        
        auth_response = supabase.auth.admin.create_user({
            "email": comercio.email,
            "password": default_password,
            "email_confirm": True
        })
        
        user_id = auth_response.user.id
        
        profile_data = {
            "id": user_id,
            "nombre_apellido": comercio.nombre_comercio,
            "dni": comercio.cuit,
            "email": comercio.email,
            "telefono": comercio.telefono,
            "rubro": comercio.rubro,
            "rol": "COMERCIO",
            "estado": "PENDIENTE",
            "municipio": final_municipio or user_municipio, # Fallback al municipio del creador si no se define
            "password_changed": False,
            "titular_id": titular_id
        }
        
        supabase.table("profiles").insert(profile_data).execute()

        commerce_data = {
            "id": user_id,
            "nombre_comercio": comercio.nombre_comercio,
            "cuit": comercio.cuit,
            "rubro": comercio.rubro,
            "direccion": comercio.direccion
        }
        supabase.table("comercios").insert(commerce_data).execute()
        
        # Auditoría
        background_tasks.add_task(registrar_auditoria, 
            usuario_id=auth_user.id if auth_user else None,
            email_usuario=auth_user.email if auth_user else "Sistema",
            rol_usuario=user_rol,
            accion="CREATE",
            tabla="profiles",
            registro_id=user_id,
            datos_anteriores=None,
            datos_nuevos=profile_data,
            modulo="Gestión Comercios",
            request=request
        )
        
        return {
            "message": f"Comercio creado correctamente. Contraseña temporal: {default_password}", 
            "comercio": profile_data
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Error al crear comercio: {str(e)}"
        )


# ── MODELOS PARA OFERTAS ──────────────────────────────────────────────────────
class OfertaRequest(BaseModel):
    titulo: str
    descripcion: Optional[str] = None
    tipo: str  # 'promocion' | 'descuento' | 'beneficio'
    descuento_porcentaje: Optional[int] = None
    imagen_url: Optional[str] = None
    fecha_fin: Optional[str] = None

class OfertaUpdateRequest(BaseModel):
    activo: Optional[bool] = None
    titulo: Optional[str] = None
    descripcion: Optional[str] = None
    imagen_url: Optional[str] = None



# ── ENDPOINTS OFERTAS ─────────────────────────────────────────────────────────

@app.get("/api/ofertas")
def listar_ofertas(user: Any = Depends(get_current_user)):
    """Lista las ofertas del comercio autenticado."""
    comercio_id = user.id
    try:
        result = supabase.table("ofertas") \
            .select("*") \
            .eq("comercio_id", comercio_id) \
            .order("created_at", desc=True) \
            .execute()
        return {"ofertas": result.data}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/ofertas", status_code=201)
def crear_oferta(oferta: OfertaRequest, request: Request, background_tasks: BackgroundTasks, user: Any = Depends(get_current_user)):
    """Crea una nueva oferta para el comercio autenticado."""
    comercio_id = user.id
    if oferta.tipo not in ["promocion", "descuento", "beneficio"]:
        raise HTTPException(status_code=400, detail="Tipo inválido. Usar: promocion, descuento, beneficio")
    try:
        data = {
            "comercio_id": comercio_id,
            "titulo": oferta.titulo,
            "descripcion": oferta.descripcion,
            "tipo": oferta.tipo,
            "descuento_porcentaje": oferta.descuento_porcentaje,
            "imagen_url": oferta.imagen_url,
            "fecha_fin": oferta.fecha_fin,
            "activo": True,
        }
        result = supabase.table("ofertas").insert(data).execute()
        
        # Auditoría
        background_tasks.add_task(registrar_auditoria, 
            usuario_id=comercio_id,
            email_usuario=None,
            rol_usuario="COMERCIO",
            accion="CREATE",
            tabla="ofertas",
            registro_id=result.data[0]["id"],
            datos_anteriores=None,
            datos_nuevos=data,
            modulo="Promociones",
            request=request
        )
        return {"message": "Oferta creada", "oferta": result.data[0]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.patch("/api/ofertas/{oferta_id}")
def actualizar_oferta(oferta_id: str, update: OfertaUpdateRequest, request: Request, background_tasks: BackgroundTasks, user: Any = Depends(get_current_user)):
    """Actualiza (activo, título, descripción) de una oferta del comercio autenticado."""
    comercio_id = user.id
    try:
        oferta_ant = supabase.table("ofertas").select("*").eq("id", oferta_id).eq("comercio_id", comercio_id).execute()
        datos_anteriores = oferta_ant.data[0] if oferta_ant.data else None
        
        update_data = {k: v for k, v in update.model_dump().items() if v is not None}
        result = supabase.table("ofertas") \
            .update(update_data) \
            .eq("id", oferta_id) \
            .eq("comercio_id", comercio_id) \
            .execute()
        if not result.data:
            raise HTTPException(status_code=404, detail="Oferta no encontrada")
            
        # Auditoría
        background_tasks.add_task(registrar_auditoria, 
            usuario_id=comercio_id,
            email_usuario=None,
            rol_usuario="COMERCIO",
            accion="UPDATE",
            tabla="ofertas",
            registro_id=oferta_id,
            datos_anteriores=datos_anteriores,
            datos_nuevos=update_data,
            modulo="Promociones",
            request=request
        )
        return {"message": "Oferta actualizada", "oferta": result.data[0]}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/api/ofertas/{oferta_id}", status_code=204)
def eliminar_oferta(oferta_id: str, request: Request, background_tasks: BackgroundTasks, user: Any = Depends(get_current_user)):
    """Elimina una oferta del comercio autenticado."""
    comercio_id = user.id
    try:
        oferta_ant = supabase.table("ofertas").select("*").eq("id", oferta_id).eq("comercio_id", comercio_id).execute()
        datos_anteriores = oferta_ant.data[0] if oferta_ant.data else None
        
        if not datos_anteriores:
            raise HTTPException(status_code=404, detail="Oferta no encontrada")

        supabase.table("ofertas") \
            .delete() \
            .eq("id", oferta_id) \
            .eq("comercio_id", comercio_id) \
            .execute()
            
        background_tasks.add_task(registrar_auditoria, 
            usuario_id=comercio_id,
            email_usuario=None,
            rol_usuario="COMERCIO",
            accion="DELETE",
            tabla="ofertas",
            registro_id=oferta_id,
            datos_anteriores=datos_anteriores,
            datos_nuevos=None,
            modulo="Promociones",
            request=request
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ── ENDPOINT PÚBLICO: ver ofertas por municipio (para socios) ─────────────────
@app.get("/api/ofertas/publicas")
def ofertas_publicas(limit: int = Query(default=50, le=100), offset: int = Query(default=0, ge=0), municipio: Optional[str] = None):
    """Ofertas activas de comercios, filtradas opcionalmente por municipio."""
    try:
        query = supabase.table("ofertas") \
            .select("*, profiles!comercio_id(nombre_apellido, municipio, rubro)") \
            .eq("activo", True) \
            .order("created_at", desc=True) \
            .range(offset, offset + limit - 1)
        if municipio:
            query = query.eq("profiles.municipio", municipio)
        result = query.execute()
        return {"ofertas": result.data}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.put("/api/perfil")
def update_profile(req: UpdateProfileRequest, request: Request,background_tasks: BackgroundTasks,  current_user  = Depends(get_current_user)):
    """
    Actualiza los datos del perfil del usuario autenticado.
    Vulnerabilidad de Mass Assignment parcheada mediante Dict Exclude.
    """
    try:
        update_data = req.dict(exclude_unset=True)
        if not update_data:
            return {"message": "Sin cambios"}
            
        perfil_ant = supabase.table("profiles").select("*").eq("id", current_user.id).execute()
        datos_anteriores = perfil_ant.data[0] if perfil_ant.data else None
            
        if "email" in update_data:
            try:
                # Update email in Supabase Auth
                supabase.auth.admin.update_user_by_id(current_user.id, {"email": update_data["email"], "email_confirm": True})
            except Exception as e:
                raise HTTPException(status_code=400, detail=f"No se pudo actualizar el email de acceso: {str(e)}")

        res = supabase.table("profiles").update(update_data).eq("id", current_user.id).execute()
        if not res.data:
            raise HTTPException(status_code=404, detail="Usuario no encontrado")
            
        background_tasks.add_task(registrar_auditoria, 
            usuario_id=current_user.id,
            email_usuario=current_user.email,
            rol_usuario=None,
            accion="UPDATE",
            tabla="profiles",
            registro_id=current_user.id,
            datos_anteriores=datos_anteriores,
            datos_nuevos=update_data,
            modulo="Perfil",
            request=request
        )
        return {"message": "Perfil actualizado", "user": res.data[0]}
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=500, detail=f"Error al editar usuario: {str(e)}")

# ── ENDPOINTS GESTIÓN DE DEPENDIENTES (ADHERENTES / EMPLEADOS) ────────────────
@app.get("/api/mis-dependientes")
def get_mis_dependientes(current_user = Depends(get_current_user)):
    """Retorna los adherentes/empleados del usuario actual."""
    try:
        res = supabase.table("profiles").select("*").eq("titular_id", current_user.id).order("created_at", desc=True).execute()
        return {"dependientes": res.data}
    except Exception as e:
         raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/agregar-dependiente", status_code=201)
def agregar_dependiente(req: AddDependienteRequest, request: Request,background_tasks: BackgroundTasks,  current_user  = Depends(get_current_user)):
    """Crea un perfil que depende del usuario en sesión."""
    try:
        # 1. Obtener perfil titular para heredar Rol y otros datos
        titular_res = supabase.table("profiles").select("rol", "municipio", "rubro").eq("id", current_user.id).execute()
        if not titular_res.data:
            raise HTTPException(status_code=404, detail="Titular no encontrado")
        titular = titular_res.data[0]
        
        # 2. Email ficticio si no provee (para Supabase Auth)
        user_email = req.email if req.email else f"dependiente.{req.dni_cuit}@sociedadrural.local"
        user_password = req.password if req.password and len(req.password) >= 6 else "socio1234"
        
        # 3. Crear usuario en Auth
        auth_response = supabase.auth.admin.create_user({
            "email": user_email,
            "password": user_password,
            "email_confirm": True
        })
        user_id = auth_response.user.id
        
        # 4. Insertar en Profiles
        profile_data = {
            "id": user_id,
            "nombre_apellido": req.nombre_apellido,
            "dni": req.dni_cuit,
            "email": user_email,
            "telefono": req.telefono,
            "rol": titular["rol"], # Hereda rol del titular (ej. SOCIO o COMERCIO)
            "estado": "APROBADO", # Dependientes pre-aprobados por el titular
            "municipio": titular["municipio"],
            "rubro": titular["rubro"],
            "titular_id": current_user.id,
            "tipo_vinculo": req.tipo_vinculo,
            "password_changed": False
        }
        
        try:
            supabase.table("profiles").insert(profile_data).execute()
            
            background_tasks.add_task(registrar_auditoria, 
                usuario_id=current_user.id,
                email_usuario=current_user.email,
                rol_usuario=titular["rol"],
                accion="CREATE",
                tabla="profiles",
                registro_id=user_id,
                datos_anteriores=None,
                datos_nuevos=profile_data,
                modulo="Gestión Dependientes",
                request=request
            )
        except Exception as e:
            supabase.auth.admin.delete_user(user_id)
            raise e
            
        return {"message": "Dependiente agregado correctamente", "dependiente": profile_data}
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=400, detail=f"Error al agregar: {str(e)}")

@app.delete("/api/dependientes/{dependiente_id}")
def eliminar_dependiente(dependiente_id: str, request: Request,background_tasks: BackgroundTasks,  current_user  = Depends(get_current_user)):
    """Desvincula y elimina a un adherente/empleado."""
    try:
        # Verificar que le pertenece
        check = supabase.table("profiles").select("*").eq("id", dependiente_id).eq("titular_id", current_user.id).execute()
        if not check.data:
            raise HTTPException(status_code=403, detail="No tienes permiso para eliminar este dependiente")
            
        datos_anteriores = check.data[0]
            
        # Eliminar de Auth borrará de Profiles en cascada (o lo hacemos manual)
        supabase.auth.admin.delete_user(dependiente_id)
        
        background_tasks.add_task(registrar_auditoria, 
            usuario_id=current_user.id,
            email_usuario=current_user.email,
            rol_usuario=None,
            accion="DELETE",
            tabla="profiles",
            registro_id=dependiente_id,
            datos_anteriores=datos_anteriores,
            datos_nuevos=None,
            modulo="Gestión Dependientes",
            request=request
        )
        
        return {"message": "Dependiente eliminado"}
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=500, detail=str(e))

from fastapi import UploadFile, File

@app.post("/api/perfil/foto")
async def upload_foto(file: UploadFile = File(...), current_user = Depends(get_current_user)):
    """
    Sube una foto al bucket 'perfiles' y actualiza la URL en el perfil.
    """
    try:
        # 1. Leer contenido del archivo
        file_content = await file.read()
        file_ext = file.filename.split(".")[-1]
        file_path = f"{current_user.id}/profile.{file_ext}"
        
        # 2. Subir a Supabase Storage (Migrado a bucket único 'business-logos')
        print(f"Uploading profile photo. Bucket: business-logos, Path: {file_path}")
        try:
            # Asegurarse de que el bucket existe antes de subir
            try:
                supabase.storage.get_bucket("business-logos")
            except Exception:
                print("Bucket 'business-logos' not found, attempting to create...")
                try:
                    supabase.storage.create_bucket("business-logos", options={"public": True})
                    print("Bucket 'business-logos' created successfully.")
                except Exception as create_err:
                    print(f"Critical error: Could not create bucket: {create_err}")

            res_storage = supabase.storage.from_("business-logos").upload(
                path=file_path,
                file=file_content,
                file_options={"content-type": file.content_type, "upsert": "true"}
            )
            print(f"Profile upload result: {res_storage}")
        except Exception as storage_err:
            print(f"Error subiendo foto al storage: {storage_err}")
            raise storage_err
        
        # 3. Obtener URL pública
        public_url = f"{SUPABASE_URL}/storage/v1/object/public/business-logos/{file_path}"
        
        # 4. Actualizar en la tabla profiles
        supabase.table("profiles").update({"foto_url": public_url}).eq("id", current_user.id).execute()
        
        return {"message": "Foto actualizada", "foto_url": public_url}
        
    except Exception as e:
        print(f"Error subiendo foto de perfil: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error subiendo foto: {str(e)}")

@app.post("/api/ofertas/foto")
async def upload_oferta_foto(file: UploadFile = File(...), current_user = Depends(get_current_user)):
    """
    Sube una foto de oferta al bucket 'ofertas'.
    """
    try:
        file_content = await file.read()
        file_ext = file.filename.split(".")[-1]
        # Usamos UUID para evitar colisiones si el mismo comercio sube varias ofertas
        filename = f"{current_user.id}/{uuid4().hex}.{file_ext}"
        
        # Subir a Supabase Storage (bucket 'business-logos')
        print(f"Uploading offer image. Bucket: business-logos, Path: {filename}")
        try:
            # Asegurarse de que el bucket existe antes de subir
            try:
                supabase.storage.get_bucket("business-logos")
            except Exception:
                print("Bucket 'business-logos' not found, attempting to create...")
                try:
                    supabase.storage.create_bucket("business-logos", options={"public": True})
                    print("Bucket 'business-logos' created successfully.")
                except Exception as create_err:
                    print(f"Critical error: Could not create bucket: {create_err}")

            res_storage = supabase.storage.from_("business-logos").upload(
                path=filename,
                file=file_content,
                file_options={"content-type": file.content_type, "upsert": "true"}
            )
            print(f"Offer image upload result: {res_storage}")
        except Exception as storage_err:
            print(f"Error en Storage (asegurese que el bucket 'business-logos' sea publico): {storage_err}")
            raise storage_err
        
        public_url = f"{SUPABASE_URL}/storage/v1/object/public/business-logos/{filename}"
        
        return {"message": "Imagen de oferta subida", "imagen_url": public_url}
        
    except Exception as e:
        print(f"Error en endpoint /api/ofertas/foto: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error subiendo imagen de oferta: {str(e)}")


@app.post("/api/notificar-olvido-password")
@limiter.limit("3/minute")
def notificar_olvido_password(req: ForgotPasswordRequest, request: Request, background_tasks: BackgroundTasks):
    """
    Registra una solicitud de recuperación de contraseña y notifica a todos los administradores.
    """
    try:
        identificador = req.identificador.strip()
        
        # 1. Buscar el perfil del usuario que solicita
        profile_res = None
        if "@" in identificador:
            profile_res = supabase.table("profiles").select("id, email, nombre_apellido, dni").eq("email", identificador).execute()
        else:
            profile_res = supabase.table("profiles").select("id, email, nombre_apellido, dni").eq("dni", identificador).execute()
            
        if not profile_res.data:
            # Por seguridad, mensaje genérico
            return {"message": "Si el usuario existe, el administrador ha sido notificado."}

        perfil = profile_res.data[0]
        
        # 2. Registrar la solicitud en notificaciones_admin
        notif_data = {
            "usuario_id": perfil["id"],
            "tipo": "OLVIDO_PASSWORD",
            "descripcion": f"El usuario {perfil['nombre_apellido']} (DNI: {perfil['dni']}) solicita restablecer su contraseña.",
            "estado": "PENDIENTE",
            "metadata": {"email": perfil["email"]}
        }
        
        res_ins = supabase.table("notificaciones_admin").insert(notif_data).execute()
        
        # 3. Notificar a todos los administradores (In-App y Push)
        # Buscamos todos los perfiles con rol ADMIN
        admins_res = supabase.table("profiles").select("id").eq("rol", "ADMIN").execute()
        if admins_res.data:
            for admin in admins_res.data:
                background_tasks.add_task(
                    enviar_notificacion_push_inapp,
                    usuario_id=admin["id"],
                    titulo="Solicitud de Soporte 🔑",
                    mensaje=f"{perfil['nombre_apellido']} olvidó su contraseña.",
                    link_url="/admin" # O una sección específica si la creamos
                )

        return {"message": "Solicitud enviada correctamente. Un administrador procesará tu pedido a la brevedad."}
        
    except Exception as e:
        logger.error(f"Error en notificar_olvido_password: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error al procesar solicitud: {str(e)}")

@app.get("/api/admin/notificaciones-soporte")
def get_support_notifications(admin_user = Depends(get_current_admin)):
    """Retorna las notificaciones de soporte pendientes para el administrador"""
    try:
        res = supabase.table("notificaciones_admin") \
            .select("*, profiles!usuario_id(nombre_apellido, dni, email, rol)") \
            .eq("estado", "PENDIENTE") \
            .order("created_at", desc=True) \
            .execute()
        return {"notificaciones": res.data}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.put("/api/admin/notificaciones-soporte/{notif_id}/resolver")
def resolve_support_notification(notif_id: str, admin_user = Depends(get_current_admin)):
    """Marca una notificación de soporte como resuelta"""
    try:
        supabase.table("notificaciones_admin").update({
            "estado": "RESUELTO",
            "resolved_at": datetime.now().isoformat()
        }).eq("id", notif_id).execute()
        return {"message": "Solicitud marcada como resuelta"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/admin/notificaciones-soporte/{notif_id}/reset-password")
def admin_reset_password(notif_id: str, req: ResetPasswordRequest, request: Request, background_tasks: BackgroundTasks, admin_user = Depends(get_current_admin)):
    """
    Permite a un administrador resetear la contraseña de un usuario que lo solicitó.
    1. Obtiene el usuario_id desde la notificación.
    2. Actualiza la contraseña en Supabase Auth.
    3. Marca la notificación como RESUELTO.
    4. Registra en auditoría.
    """
    try:
        # 1. Obtener la notificación
        notif_res = supabase.table("notificaciones_admin").select("*").eq("id", notif_id).execute()
        if not notif_res.data:
            raise HTTPException(status_code=404, detail="Notificación no encontrada")
        
        notif = notif_res.data[0]
        user_id = notif.get("usuario_id")
        
        if not user_id:
            raise HTTPException(status_code=400, detail="La notificación no tiene un usuario_id asociado")

        # 2. Actualizar contraseña en Auth (usando admin privilegios)
        try:
            supabase.auth.admin.update_user_by_id(user_id, {
                "password": req.new_password,
                "email_confirm": True
            })
            
            # Forzar flag de password_changed a False para que el usuario deba cambiarla al entrar si es política
            supabase.table("profiles").update({"password_changed": False}).eq("id", user_id).execute()
            
        except Exception as auth_err:
            raise HTTPException(status_code=400, detail=f"Error actualizando contraseña en Auth: {str(auth_err)}")

        # 3. Resolver notificación
        supabase.table("notificaciones_admin").update({
            "estado": "RESUELTO",
            "resolved_at": datetime.now().isoformat()
        }).eq("id", notif_id).execute()

        # 4. Auditoría
        perfil_res = supabase.table("profiles").select("email").eq("id", user_id).execute()
        user_email = perfil_res.data[0]["email"] if perfil_res.data else "unknown"
        
        background_tasks.add_task(registrar_auditoria, 
            usuario_id=admin_user.id,
            email_usuario=admin_user.email,
            rol_usuario="ADMIN",
            accion="RESET_PASSWORD_ADMIN",
            tabla="auth.users",
            registro_id=user_id,
            datos_anteriores={"notif_id": notif_id},
            datos_nuevos={"user_email": user_email, "status": "Password Reseteado por Admin"},
            modulo="Soporte",
            request=request
        )

        return {"message": "Contraseña actualizada exitosamente y solicitud resuelta."}

    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=500, detail=f"Error al resetear contraseña: {str(e)}")

# ── ENDPOINT DE AUDITORÍA (ADMIN) ─────────────────────────────────────────────
@app.get("/api/admin/auditoria")
def get_auditoria(
    request: Request,
    superadmin_user = Depends(get_current_superadmin),
    usuario_id: Optional[str] = None,
    accion: Optional[str] = None,
    tabla_afectada: Optional[str] = None,
    modulo: Optional[str] = None,
    limit: int = Query(default=50, le=100),
    offset: int = Query(default=0, ge=0)
):
    """
    Retorna los registros de auditoría. Exclusivo para el rol Administrador.
    """
    try:
        query = supabase.table("auditoria_logs").select("*").order("fecha", desc=True)
        
        if usuario_id:
            query = query.eq("usuario_id", usuario_id)
        if accion:
            query = query.eq("accion", accion)
        if tabla_afectada:
            query = query.eq("tabla_afectada", tabla_afectada)
        if modulo:
            query = query.eq("modulo", modulo)
            
        res = query.range(offset, offset + limit - 1).execute()
        return {"logs": res.data}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error obteniendo logs de auditoría: {str(e)}")

# ─────────────────────────────────────────────────────────────────
# 11. ENDPOINTS GESTIÓN DE EVENTOS INSTITUCIONALES
# ─────────────────────────────────────────────────────────────────
@app.get("/api/eventos")
def get_combined_eventos(
    municipio: Optional[str] = None,
    tipo: Optional[str] = None,
    fecha_desde: Optional[str] = None
):
    """
    Consulta la lista de eventos combinando eventos institucionales y 
    eventos importados de redes sociales (aprobados).
    """
    try:
        # 1. Obtener eventos institucionales
        query1 = supabase.table("eventos").select("*")
        if municipio:
            query1 = query1.ilike("lugar", f"%{municipio}%")
        if tipo:
            query1 = query1.ilike("tipo", f"%{tipo}%")
        if fecha_desde:
            query1 = query1.gte("fecha", fecha_desde)
            
        res1 = query1.order("fecha", desc=False).execute()
        eventos_inst = res1.data or []

        # 2. Obtener eventos de redes sociales (aprobados)
        query2 = supabase.table("eventos_sociales").select("*").eq("status", "aprobado")
        if municipio:
            query2 = query2.ilike("lugar", f"%{municipio}%")
        if tipo:
            # Buscamos en el titulo para eventos sociales
            query2 = query2.ilike("titulo", f"%{tipo}%")
        if fecha_desde:
            query2 = query2.gte("fecha_evento", fecha_desde)
            
        res2 = query2.order("fecha_evento", desc=False).execute()
        eventos_soc = res2.data or []
        
        # 3. Normalizar eventos sociales al esquema que espera el frontend
        social_normalized = []
        for ev in eventos_soc:
            social_normalized.append({
                "id": ev["id"],
                "titulo": ev["titulo"],
                "descripcion": ev.get("descripcion_limpia", ""),
                "lugar": ev.get("lugar", "A definir"),
                "fecha": ev["fecha_evento"],
                "hora": ev["hora_evento"],
                "tipo": "Social", # Etiqueta para distinguir origen
                "imagen_url": ev.get("imagen_url")
            })
            
        # 4. Combinar y ordenar por fecha
        combined = eventos_inst + social_normalized
        combined.sort(key=lambda x: x["fecha"])
        
        return {"eventos": combined}
    except Exception as e:
        logger.error(f"Error combinando eventos: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error al obtener eventos: {str(e)}")

@app.post("/api/admin/eventos", status_code=201)
def create_evento(evento: EventCreate, request: Request, background_tasks: BackgroundTasks, admin_user = Depends(get_current_admin)):
    """Crea un nuevo evento desde el Panel Administrador"""
    try:
        evento_data = evento.dict()
        res = supabase.table("eventos").insert(evento_data).execute()
        
        if res.data:
            evento_creado = res.data[0]
            background_tasks.add_task(registrar_auditoria, 
                usuario_id=admin_user.id,
                email_usuario=admin_user.email,
                rol_usuario="ADMIN",
                accion="CREATE",
                tabla="eventos",
                registro_id=evento_creado["id"],
                datos_anteriores=None,
                datos_nuevos=evento_data,
                modulo="Gestión Eventos",
                request=request
            )
            return {"message": "Evento creado exitosamente", "evento": evento_creado}
        raise HTTPException(status_code=500, detail="Error desconocido al insertar evento")
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=500, detail=f"Error al crear evento: {str(e)}")

@app.delete("/api/admin/eventos/{evento_id}")
def delete_evento(evento_id: str, request: Request, background_tasks: BackgroundTasks, admin_user = Depends(get_current_admin)):
    """Elimina un evento desde el Panel Administrador"""
    try:
        evento_ant = supabase.table("eventos").select("*").eq("id", evento_id).execute()
        datos_anteriores = evento_ant.data[0] if evento_ant.data else None
        
        if not datos_anteriores:
            raise HTTPException(status_code=404, detail="Evento no encontrado")

        supabase.table("eventos").delete().eq("id", evento_id).execute()
        
        background_tasks.add_task(registrar_auditoria, 
            usuario_id=admin_user.id,
            email_usuario=admin_user.email,
            rol_usuario="ADMIN",
            accion="DELETE",
            tabla="eventos",
            registro_id=evento_id,
            datos_anteriores=datos_anteriores,
            datos_nuevos=None,
            modulo="Gestión Eventos",
            request=request
        )
        return {"message": "Evento eliminado correctamente"}
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=500, detail=f"Error al eliminar evento: {str(e)}")

@app.put("/api/admin/eventos/{evento_id}")
def update_evento(evento_id: str, req: EventUpdate, request: Request, background_tasks: BackgroundTasks, admin_user = Depends(get_current_admin)):
    """Actualiza un evento desde el Panel Administrador"""
    try:
        update_data = {k: v for k, v in req.dict().items() if v is not None}
        if not update_data:
            return {"message": "Sin cambios"}

        evento_ant = supabase.table("eventos").select("*").eq("id", evento_id).execute()
        datos_anteriores = evento_ant.data[0] if evento_ant.data else None
        
        if not datos_anteriores:
            raise HTTPException(status_code=404, detail="Evento no encontrado")

        res = supabase.table("eventos").update(update_data).eq("id", evento_id).execute()
        
        background_tasks.add_task(registrar_auditoria, 
            usuario_id=admin_user.id,
            email_usuario=admin_user.email,
            rol_usuario="ADMIN",
            accion="UPDATE",
            tabla="eventos",
            registro_id=evento_id,
            datos_anteriores=datos_anteriores,
            datos_nuevos=update_data,
            modulo="Gestión Eventos",
            request=request
        )
        return {"message": "Evento actualizado correctamente", "evento": res.data[0]}
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=500, detail=f"Error al actualizar evento: {str(e)}")


@app.post("/api/v1/importar-evento")
async def importar_evento(payload: WebhookEventoPayload, request: Request):
    """
    Endpoint para recibir publicaciones de Make.com (Instagram/Facebook).
    Procesa el texto, guarda la imagen en Storage y persiste en la tabla eventos_sociales.
    """
    # 1. Validar Token de seguridad o Webhook Secret
    token = request.headers.get("X-Webhook-Token")
    secret_header = request.headers.get("x-webhook-secret")
    
    # Prioridad al secreto definido en el SPEC para Make.com
    webhook_secret = os.getenv("WEBHOOK_SECRET", "make_webhook_secret_2026")
    secret_token = os.getenv("WEBHOOK_SECRET_TOKEN")
    
    authorized = False
    if secret_header and secret_header == webhook_secret:
        authorized = True
    elif token and secret_token and token == secret_token:
        authorized = True
        
    if not authorized:
        logger.warning(f"Intento de acceso no autorizado al webhook desde IP {request.client.host if request.client else 'unknown'}")
        print(f"Webhook mismatch. Recibido secret: {secret_header}, Recibido token: {token}")
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Webhook secret mismatch o token no válido")

    try:
        # 2. Procesar Texto con Regex
        datos_procesados = procesar_texto_evento(payload.caption)
        
        # 3. Procesar Imagen (Descargar y subir a Supabase Storage)
        url_final_imagen = procesar_imagen_evento(payload.media_url, payload.post_id)
        
        # 4. Preparar datos para inserción/actualización
        remate_data = {
            "external_id": payload.post_id,
            "titulo": datos_procesados["titulo"],
            "descripcion_limpia": datos_procesados["descripcion_limpia"],
            "lugar": datos_procesados["lugar"],
            "fecha_evento": datos_procesados["fecha_evento"],
            "hora_evento": datos_procesados["hora_evento"],
            "imagen_url": url_final_imagen,
            "metadata": {
                "original_caption": payload.caption,
                "original_media_url": payload.media_url,
                "timestamp": payload.timestamp
            },
            "status": "borrador" # Por defecto entra para aprobación manual
        }
        
        # 5. Persistencia (Upsert por external_id)
        # La tabla debe tener external_id como UNIQUE
        res = supabase.table("eventos_sociales").upsert(remate_data, on_conflict="external_id").execute()
        
        if res.data:
            logger.info(f"Evento importado exitosamente: {payload.post_id}")
            return {
                "status": "success", 
                "message": "Evento procesado correctamente",
                "id": res.data[0].get("id"),
                "external_id": payload.post_id
            }
        
        return {"status": "success", "external_id": payload.post_id}
        
    except Exception as e:
        logger.error(f"Error crítico procesando evento webhook {payload.post_id}: {str(e)}")
        # No queremos dar demasiados detalles del error interno al webhook remoto
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, 
            detail="Error interno procesando el remate"
        )



# ── ENDPOINTS GESTIÓN DE EVENTOS DE REDES SOCIALES (ADMIN) ───────────────────
@app.get("/api/admin/eventos-sociales")
def get_all_social_eventos(limit: int = 50, offset: int = 0, admin_user = Depends(get_current_admin)):
    """Retorna todos los eventos importados de redes sociales para gestión admin"""
    try:
        response = supabase.table("eventos_sociales").select("*").order("created_at", desc=True).range(offset, offset + limit - 1).execute()
        return {"eventos": response.data}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

class UpdateEventoSocialStatusRequest(BaseModel):
    status: str # "borrador" | "aprobado" | "rechazado"

@app.put("/api/admin/eventos-sociales/{evento_id}/status")
def update_evento_social_status(evento_id: str, req: UpdateEventoSocialStatusRequest, request: Request, background_tasks: BackgroundTasks, admin_user = Depends(get_current_admin)):
    """Aprueba o rechaza un evento de redes sociales"""
    try:
        evento_ant = supabase.table("eventos_sociales").select("*").eq("id", evento_id).execute()
        datos_anteriores = evento_ant.data[0] if evento_ant.data else None
        
        if not datos_anteriores:
            raise HTTPException(status_code=404, detail="Evento no encontrado")

        res = supabase.table("eventos_sociales").update({"status": req.status}).eq("id", evento_id).execute()
        
        background_tasks.add_task(registrar_auditoria, 
            usuario_id=admin_user.id,
            email_usuario=admin_user.email,
            rol_usuario="ADMIN",
            accion="UPDATE_STATUS",
            tabla="eventos_sociales",
            registro_id=evento_id,
            datos_anteriores=datos_anteriores,
            datos_nuevos={"status": req.status},
            modulo="Gestión Eventos Sociales",
            request=request
        )
        return {"message": f"Estado actualizado a {req.status}", "evento": res.data[0]}
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=500, detail=f"Error al actualizar estado del evento: {str(e)}")

class EventoSocialUpdate(BaseModel):
    titulo: Optional[str] = None
    descripcion_limpia: Optional[str] = None
    lugar: Optional[str] = None
    fecha_evento: Optional[str] = None
    hora_evento: Optional[str] = None
    imagen_url: Optional[str] = None

@app.put("/api/admin/eventos-sociales/{evento_id}")
def update_evento_social(evento_id: str, req: EventoSocialUpdate, request: Request, background_tasks: BackgroundTasks, admin_user = Depends(get_current_admin)):
    """Actualiza un evento de redes sociales desde el Panel Administrador"""
    try:
        update_data = {k: v for k, v in req.dict().items() if v is not None}
        if not update_data:
            return {"message": "Sin cambios"}

        evento_ant = supabase.table("eventos_sociales").select("*").eq("id", evento_id).execute()
        datos_anteriores = evento_ant.data[0] if evento_ant.data else None
        
        if not datos_anteriores:
            raise HTTPException(status_code=404, detail="Evento no encontrado")

        res = supabase.table("eventos_sociales").update(update_data).eq("id", evento_id).execute()
        
        background_tasks.add_task(registrar_auditoria, 
            usuario_id=admin_user.id,
            email_usuario=admin_user.email,
            rol_usuario="ADMIN",
            accion="UPDATE",
            tabla="eventos_sociales",
            registro_id=evento_id,
            datos_anteriores=datos_anteriores,
            datos_nuevos=update_data,
            modulo="Gestión Eventos Sociales",
            request=request
        )
        return {"message": "Evento actualizado correctamente", "evento": res.data[0]}
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=500, detail=f"Error al actualizar evento: {str(e)}")

@app.delete("/api/admin/eventos-sociales/{evento_id}")
def delete_evento_social(evento_id: str, request: Request, background_tasks: BackgroundTasks, admin_user = Depends(get_current_admin)):
    """Elimina un evento de redes sociales"""
    try:
        evento_ant = supabase.table("eventos_sociales").select("*").eq("id", evento_id).execute()
        datos_anteriores = evento_ant.data[0] if evento_ant.data else None
        
        if not datos_anteriores:
            raise HTTPException(status_code=404, detail="Evento no encontrado")

        supabase.table("eventos_sociales").delete().eq("id", evento_id).execute()
        
        background_tasks.add_task(registrar_auditoria, 
            usuario_id=admin_user.id,
            email_usuario=admin_user.email,
            rol_usuario="ADMIN",
            accion="DELETE",
            tabla="eventos_sociales",
            registro_id=evento_id,
            datos_anteriores=datos_anteriores,
            datos_nuevos=None,
            modulo="Gestión Eventos Sociales",
            request=request
        )
        return {"message": "Evento eliminado correctamente"}
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=500, detail=f"Error al eliminar evento: {str(e)}")


# ── ENDPOINTS DE NOTIFICACIONES Y FCM ───────────────────────────────────────

class PushTokenRequest(BaseModel):
    token: str
    plataforma: str = "web"

@app.post("/api/push-tokens")
def register_push_token(req: PushTokenRequest, current_user = Depends(get_current_user)):
    """Registra o actualiza el token FCM del usuario conectado"""
    try:
        # Upsert token (usualmente un usuario tiene un token por dispositivo,
        # simplificamos guardando el último o actualizando si ya existe).
        # Verificamos si el token existe
        existente = supabase.table("push_tokens").select("id").eq("token", req.token).execute()
        if existente.data:
            supabase.table("push_tokens").update({
                "usuario_id": current_user.id,
                "plataforma": req.plataforma
            }).eq("token", req.token).execute()
        else:
            supabase.table("push_tokens").insert({
                "usuario_id": current_user.id,
                "token": req.token,
                "plataforma": req.plataforma
            }).execute()
            
        return {"message": "Token registrado exitosamente"}
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=500, detail=f"Error al registrar token: {str(e)}")


@app.get("/api/notificaciones")
def get_user_notifications(limit: int = 50, current_user = Depends(get_current_user)):
    """Obtiene las notificaciones in-app del usuario conectado"""
    try:
        response = supabase.table("notificaciones_usuarios") \
            .select("*") \
            .eq("usuario_id", current_user.id) \
            .order("created_at", desc=True) \
            .limit(limit) \
            .execute()
        
        # Conteo de no leídas
        no_leidas = sum(1 for n in response.data if not n.get("leido", True))
            
        return {
            "notificaciones": response.data,
            "no_leidas": no_leidas
        }
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=500, detail=f"Error obteniendo notificaciones: {str(e)}")


@app.put("/api/notificaciones/marcar-leidas")
def mark_notifications_read(current_user = Depends(get_current_user)):
    """Marca todas las notificaciones del usuario como leídas (o saca la bolita roja)"""
    try:
        supabase.table("notificaciones_usuarios") \
            .update({"leido": True}) \
            .eq("usuario_id", current_user.id) \
            .eq("leido", False) \
            .execute()
            
        return {"message": "Notificaciones marcadas como leídas"}
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=500, detail=f"Error al actualizar notificaciones: {str(e)}")


def enviar_notificacion_push_inapp(usuario_id: str, titulo: str, mensaje: str, link_url: Optional[str] = None):
    """
    Función utilitaria (interna) para enviar una notificación In-App y Push (vía FCM) a un usuario.
    Debe ser llamada de manera asíncrona o bloqueante según sea necesario.
    """
    try:
        # 1. Guardar Notificación In-App en Base de Datos
        supabase.table("notificaciones_usuarios").insert({
            "usuario_id": usuario_id,
            "titulo": titulo,
            "mensaje": mensaje,
            "link_url": link_url
        }).execute()
        
        # 2. Obtener Token(s) FCM asociados al usuario para envíos Push
        tokens_res = supabase.table("push_tokens").select("token").eq("usuario_id", usuario_id).execute()
        push_tokens = [t["token"] for t in tokens_res.data] if tokens_res.data else []
        
        # 3. Disparar FCM si está configurado y hay tokens
        if push_tokens:
            try:
                # Utilizamos firebase_admin si está instanciado
                firebase_admin.get_app()
                
                push_message = messaging.MulticastMessage(
                    notification=messaging.Notification(
                        title=titulo,
                        body=mensaje,
                    ),
                    data={"link_url": link_url or "/"},
                    tokens=push_tokens,
                )
                messaging.send_each_for_multicast(push_message)
            except ValueError:
                print("Firebase no inicializado. Se guardó In-App pero no se envió Push.")
            except Exception as e:
                print(f"Error al enviar Push a fcm: {e}")
                
    except Exception as e:
        print(f"Error general en enviar_notificacion_push_inapp: {e}")

@app.post("/api/notificaciones/test")
def test_send_notification(current_user = Depends(get_current_admin)):
    """Endpoint de QA: Manda una notificación in-app y push al propio admin logueado"""
    enviar_notificacion_push_inapp(
        usuario_id=current_user.id,
        titulo="Notificación de Prueba 🚀",
        mensaje="Si ves esto, las notificaciones in-app y Push están funcionando correctamente en tu dispositivo.",
        link_url="/"
    )
    return {"message": "Notificación disparada."}

def enviar_whatsapp(telefono: str, mensaje: str):
    """
    Función utilitaria para enviar mensajes de WhatsApp vía Evolution API.
    Se recomienda usar números con formato internacional (ej: 549...).
    """
    try:
        url_base = os.getenv("EVOLUTION_API_URL")
        instance = os.getenv("INSTANCE_NAME")
        apikey = os.getenv("EVOLUTION_API_TOKEN")

        if not all([url_base, instance, apikey]):
            print("Configuración de WhatsApp incompleta. Verifique EVOLUTION_API_URL, INSTANCE_NAME y EVOLUTION_API_TOKEN.")
            return

        # Asegurar que la URL tenga el protocolo correcto
        if url_base and not url_base.startswith(("http://", "https://")):
            url_base = f"https://{url_base}"

        from urllib.parse import quote
        url = f"{url_base}/message/sendText/{quote(instance)}"
        headers = {
            "Content-Type": "application/json",
            "apikey": apikey
        }
        
        # Limpiar el teléfono (solo dígitos)
        numero_limpio = "".join(filter(str.isdigit, telefono))
        
        # Lógica para Argentina: Si tiene 10 dígitos (ej: 3794xxxxxx), anteponer 549
        if len(numero_limpio) == 10:
            numero_limpio = f"549{numero_limpio}"
        # Si tiene 11 dígitos y empieza con 15 (común en AR), corregir a 549 + area + resto
        elif len(numero_limpio) == 11 and numero_limpio.startswith("15"):
             # Este es un caso borde, mejor dejarlo pasar o intentar normalizarlo si conocemos el area
             pass
        # Si empieza con 379 y tiene 10 digitos ya fue cubierto arriba. 
        # Si tiene 13 y empieza con 549, ya está correcto.
        
        payload = {
            "number": numero_limpio,
            "text": mensaje,
            "delay": 1200,
            "linkPreview": True
        }
        
        response = requests.post(url, json=payload, headers=headers)
        if response.status_code not in [200, 201]:
            print(f"Error Evolution API: {response.status_code} - {response.text}")
            
    except Exception as e:
        print(f"Error crítico enviando WhatsApp: {str(e)}")

# ─────────────────────────────────────────────────────────────────────────────
# 12. MÓDULO CONTABLE 2.0: PAGOS, VALIDACIÓN Y AUTOMATIZACIÓN
# ─────────────────────────────────────────────────────────────────────────────

class SubirComprobanteRequest(BaseModel):
    mes: int
    anio: int

class AprobarPagoRequest(BaseModel):
    pago_id: str

class RechazarPagoRequest(BaseModel):
    pago_id: str
    motivo: str

# 12.1 SOCIO: Subir comprobante de pago
@app.post("/api/pagos/subir-comprobante")
async def subir_comprobante(
    request: Request,
    background_tasks: BackgroundTasks,
    mes: int = Form(...),
    anio: int = Form(...),
    file: UploadFile = File(...),
    current_user = Depends(get_current_user)
):
    try:
        # 1. Leer y subir archivo a Storage
        file_content = await file.read()
        file_ext = file.filename.split(".")[-1]
        filename = f"{current_user.id}/{anio}_{mes}_{uuid4().hex}.{file_ext}"
        
        supabase.storage.from_("comprobantes-pagos").upload(
            path=filename,
            file=file_content,
            file_options={"content-type": file.content_type, "upsert": "true"}
        )
        
        comprobante_url = f"{SUPABASE_URL}/storage/v1/object/authenticated/comprobantes-pagos/{filename}"
        
        # 2. Registrar/Actualizar en pagos_cuotas
        # Buscamos si ya existe un registro para ese mes/anio/socio
        pago_existente = supabase.table("pagos_cuotas") \
            .select("id") \
            .eq("socio_id", current_user.id) \
            .eq("fecha_vencimiento", f"{anio}-{mes:02d}-10") \
            .execute()
            
        pago_data = {
            "socio_id": current_user.id,
            "estado_pago": "PENDIENTE_VALIDACION",
            "comprobante_url": comprobante_url,
            "fecha_envio_comprobante": datetime.now().isoformat()
        }
        
        if pago_existente.data:
            pago_id = pago_existente.data[0]["id"]
            supabase.table("pagos_cuotas").update(pago_data).eq("id", pago_id).execute()
        else:
            # Si no existe, creamos uno nuevo (monto por defecto si no hay deuda previa registrada)
            pago_data["monto"] = 0 # El admin lo corregirá o vendrá de la mora detectada
            pago_data["fecha_vencimiento"] = f"{anio}-{mes:02d}-10"
            res = supabase.table("pagos_cuotas").insert(pago_data).execute()
            pago_id = res.data[0]["id"]

        # 3. Registrar Log de Actividad
        log_entry = {
            "socio_id": current_user.id,
            "tipo_evento": "COMPROBANTE_SUBIDO",
            "descripcion": f"El socio subió comprobante para la cuota {mes}/{anio}",
            "usuario_id": current_user.id
        }
        supabase.table("activity_log").insert(log_entry).execute()
        
        # 4. Auditoría
        background_tasks.add_task(registrar_auditoria, 
            usuario_id=current_user.id,
            email_usuario=current_user.email,
            rol_usuario="SOCIO",
            accion="UPLOAD",
            tabla="pagos_cuotas",
            registro_id=pago_id,
            datos_anteriores=None,
            datos_nuevos=pago_data,
            modulo="Finanzas",
            request=request
        )
        
        return {"message": "Comprobante enviado correctamente. Pendiente de validación administrativa.", "pago_id": pago_id}
        
    except Exception as e:
        logger.error(f"Error en subir_comprobante: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error al subir comprobante: {str(e)}")

# 12.2 ADMIN: Bandeja de pagos pendientes
@app.get("/api/admin/pagos/pendientes")
def get_pagos_pendientes(admin_user = Depends(get_current_admin)):
    try:
        res = supabase.table("pagos_cuotas") \
            .select("*, profiles!socio_id(nombre_apellido, dni, email)") \
            .eq("estado_pago", "PENDIENTE_VALIDACION") \
            .order("fecha_envio_comprobante", desc=False) \
            .execute()
        return {"pendientes": res.data}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# 12.3 ADMIN: Aprobar Pago
@app.post("/api/admin/pagos/aprobar")
def aprobar_pago(
    req: AprobarPagoRequest, 
    request: Request, 
    background_tasks: BackgroundTasks, 
    admin_user = Depends(get_current_admin)
):
    try:
        # 1. Obtener datos del pago y socio
        pago_res = supabase.table("pagos_cuotas").select("socio_id, monto").eq("id", req.pago_id).execute()
        if not pago_res.data:
            raise HTTPException(status_code=404, detail="Pago no encontrado")
        
        socio_id = pago_res.data[0]["socio_id"]
        
        # 2. Actualizar pago
        supabase.table("pagos_cuotas").update({
            "estado_pago": "PAGADO",
            "fecha_validacion": datetime.now().isoformat(),
            "admin_validador_id": admin_user.id
        }).eq("id", req.pago_id).execute()
        
        # 3. Reactivar Socio
        supabase.table("profiles").update({
            "estado": "APROBADO",
            "motivo": None
        }).eq("id", socio_id).execute()
        
        # 4. Registrar Log y Notificación
        supabase.table("activity_log").insert({
            "socio_id": socio_id,
            "tipo_evento": "PAGO_APROBADO",
            "descripcion": "Pago validado por Administración. Socio reactivado.",
            "usuario_id": admin_user.id
        }).execute()
        
        # 5. Auditoría
        background_tasks.add_task(registrar_auditoria, 
            usuario_id=admin_user.id,
            email_usuario=admin_user.email,
            rol_usuario="ADMIN",
            accion="APPROVE_PAYMENT",
            tabla="pagos_cuotas",
            registro_id=req.pago_id,
            datos_anteriores=None,
            datos_nuevos={"estado_pago": "PAGADO"},
            modulo="Finanzas",
            request=request
        )
        
        # 6. Notificación App interna y WhatsApp
        enviar_notificacion_push_inapp(
            socio_id, 
            "Pago Aprobado ✅", 
            "Tu pago ha sido validado correctamente. Tu carnet está activo nuevamente.",
            "/cuotas"
        )
        
        # Obtener teléfono para WhatsApp
        perfil_res = supabase.table("profiles").select("telefono").eq("id", socio_id).execute()
        if perfil_res.data and perfil_res.data[0].get("telefono"):
            mensaje_wa = "¡Tu pago ha sido validado! ✅ Tu carnet de la Sociedad Rural ya está activo. Podés verlo en la app: https://sociedadruraldelnorte.agentech.ar"
            background_tasks.add_task(enviar_whatsapp, perfil_res.data[0]["telefono"], mensaje_wa)
        
        return {"message": "Pago aprobado y socio reactivado correctamente."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# 12.4 ADMIN: Rechazar Pago
@app.post("/api/admin/pagos/rechazar")
def rechazar_pago(
    req: RechazarPagoRequest, 
    request: Request, 
    background_tasks: BackgroundTasks, 
    admin_user = Depends(get_current_admin)
):
    try:
        pago_res = supabase.table("pagos_cuotas").select("socio_id").eq("id", req.pago_id).execute()
        if not pago_res.data:
            raise HTTPException(status_code=404, detail="Pago no encontrado")
        
        socio_id = pago_res.data[0]["socio_id"]
        
        supabase.table("pagos_cuotas").update({
            "estado_pago": "RECHAZADO"
        }).eq("id", req.pago_id).execute()
        
        supabase.table("activity_log").insert({
            "socio_id": socio_id,
            "tipo_evento": "PAGO_RECHAZADO",
            "descripcion": f"Comprobante rechazado: {req.motivo}",
            "usuario_id": admin_user.id
        }).execute()
        
        enviar_notificacion_push_inapp(
            socio_id, 
            "Pago Rechazado ❌", 
            f"No pudimos validar tu comprobante. Motivo: {req.motivo}",
            "/cuotas"
        )
        
        # WhatsApp de rechazo
        perfil_res = supabase.table("profiles").select("telefono").eq("id", socio_id).execute()
        if perfil_res.data and perfil_res.data[0].get("telefono"):
            mensaje_wa = f"Hola, hubo un problema con la validación de tu pago. ❌ Motivo: {req.motivo}. Por favor revisalo en la app."
            background_tasks.add_task(enviar_whatsapp, perfil_res.data[0]["telefono"], mensaje_wa)
        
        return {"message": "Pago rechazado."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# 12.5 AUTOMACIÓN: Detección de Mora (Cron)
@app.post("/api/cron/detectar-mora")
def detectar_mora(request: Request, background_tasks: BackgroundTasks, admin_user = Depends(get_current_admin_optional)):
    """
    Motor de detección de mora. 
    Ejecución automática compatible con Cron o manual por Admin.
    """
    hoy = datetime.now()
    
    # Si NO es admin, validar que sea después del día 10 (regla automática)
    if not admin_user and hoy.day < 10:
        return {"message": "Aún no es fecha de mora automática (esperar al día 11)"}
        
    try:
        # 1. Buscar socios que NO tengan pago para el mes actual
        mes_actual = hoy.month
        anio_actual = hoy.year
        fecha_venci = f"{anio_actual}-{mes_actual:02d}-10"
        
        # Obtenemos todos los miembros (Socios y Comercios) aprobados y restringidos
        # También incluimos ADMIN para pruebas si se busca a "Vic Tor"
        query = supabase.table("profiles").select("id, nombre_apellido, telefono, rol") \
            .in_("estado", ["APROBADO", "RESTRINGIDO"])
        
        # Filtro especial para pruebas solicitado por el usuario
        if admin_user:
             # Si es ejecución manual por admin, permitimos ver a todos para el filtro de nombre
             pass
        else:
             # Si es automático, solo roles específicos
             query = query.in_("rol", ["SOCIO", "COMERCIO"])

        socios_res = query.ilike("nombre_apellido", "%Vic Tor%").execute()
        socios = socios_res.data
        
        detectados = 0
        for socio in socios:
            # Verificar si existe pago PAGADO o PENDIENTE_VALIDACION para este mes
            pago_check = supabase.table("pagos_cuotas") \
                .select("id") \
                .eq("socio_id", socio["id"]) \
                .eq("fecha_vencimiento", fecha_venci) \
                .in_("estado_pago", ["PAGADO", "PENDIENTE_VALIDACION"]) \
                .execute()
                
            if not pago_check.data:
                # Marcar como moroso (RESTRINGIDO)
                supabase.table("profiles").update({
                    "estado": "RESTRINGIDO",
                    "motivo": f"Mora automática cuota {mes_actual}/{anio_actual}"
                }).eq("id", socio["id"]).execute()
                
                # Crear deuda en pagos_cuotas si no existe
                supabase.table("pagos_cuotas").upsert({
                    "socio_id": socio["id"],
                    "monto": 5000, # Monto base ejemplo, debería venir de una config
                    "fecha_vencimiento": fecha_venci,
                    "estado_pago": "PENDIENTE"
                }, on_conflict="socio_id,fecha_vencimiento").execute()
                
                # Log Actividad
                supabase.table("activity_log").insert({
                    "socio_id": socio["id"],
                    "tipo_evento": "MORA_DETECTADA",
                    "descripcion": f"Detección automática de mora para cuota {mes_actual}/{anio_actual}",
                    "usuario_id": None # Sistema
                }).execute()

                # Notificación WhatsApp de Mora
                if socio.get("telefono"):
                    mensaje_wa = (
                        f"Hola {socio['nombre_apellido']}! 👋\n"
                        f"Detectamos un atraso en el pago de tu cuota de la Sociedad Rural ({mes_actual}/{anio_actual}).\n\n"
                        "¿Deseás regularizar tu situación? Respondé *SÍ*, *ACEPTO* o *PAGAR* para enviarte el detalle de tu deuda y el link de pago."
                    )
                    # Usamos delay para no saturar la API si son muchos
                    enviar_whatsapp(socio["telefono"], mensaje_wa)
                    detectados += 1
                
        return {"message": f"Proceso completado. Socios detectados en mora: {detectados}"}
        
    except Exception as e:
        logger.error(f"Error en detectar_mora: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# 12.5b TEST: Endpoint de prueba directa WhatsApp (Solo Admin)
class TestWhatsAppRequest(BaseModel):
    numero: str  # ej: 3794330172
    mensaje: Optional[str] = None

@app.post("/api/admin/test-whatsapp")
def test_whatsapp_directo(req: TestWhatsAppRequest, admin_user = Depends(get_current_admin)):
    """
    Envía un mensaje de WhatsApp de prueba directa a un número específico.
    Permite verificar la conectividad con Evolution API independientemente del motor de mora.
    """
    try:
        mensaje = req.mensaje or (
            "🔔 *PRUEBA - SOCIEDAD RURAL DEL NORTE*\n\n"
            "Este es un mensaje de prueba del sistema automático de notificaciones. "
            "Si recibiste este mensaje, la integración con WhatsApp está funcionando correctamente.\n\n"
            "_Sociedad Rural del Norte de Corrientes_"
        )
        enviar_whatsapp(req.numero, mensaje)
        return {"message": f"Mensaje enviado al número {req.numero}. Verificá el celular."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/mis-pagos")
def get_mis_pagos(current_user = Depends(get_current_user)):
    try:
        res = supabase.table("pagos_cuotas") \
            .select("*") \
            .eq("socio_id", current_user.id) \
            .order("fecha_vencimiento", desc=True) \
            .execute()
        return {"pagos": res.data}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/admin/users/{user_id}/activity")
def get_user_activity(user_id: str, admin_user = Depends(get_current_admin)):
    """Consulta el historial de actividades de un socio específico"""
    try:
        # Validar UUID
        try:
            uuid.UUID(user_id)
        except ValueError:
            return {"activity": []} # Si es simulado o inválido, retornar vacío
            
        res = supabase.table("activity_log") \
            .select("*") \
            .eq("socio_id", user_id) \
            .order("fecha", desc=True) \
            .execute()
        return {"activity": res.data}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# 12.6 REPORTES: Exportación de Socios (Excel/PDF)
@app.get("/api/admin/reports/socios/excel")
def exportar_socios_excel(admin_user = Depends(get_current_admin)):
    """Genera un reporte en Excel (.xlsx) nativo con la lista de socios."""
    try:
        import pandas as pd
        # Consultar socios y comercios (que actúan como socios en el sistema)
        print(f"[REPORTS] Solicitando perfiles para rol: SOCIO, COMERCIO, ADMIN")
        res = supabase.table("profiles") \
            .select("nombre_apellido, dni, email, telefono, estado, municipio, created_at, rol") \
            .in_("rol", ["SOCIO", "COMERCIO", "ADMIN"]) \
            .execute()
        
        print(f"[REPORTS] Datos encontrados: {len(res.data) if res.data else 0}")
            
        if not res.data:
            return JSONResponse(status_code=404, content={"detail": "No hay socios para exportar"})
            
        df = pd.DataFrame(res.data)
        
        # Mapeo de nombres de columnas
        cols_map = {
            "nombre_apellido": "Nombre y Apellido",
            "dni": "DNI",
            "email": "Email",
            "telefono": "Teléfono",
            "estado": "Estado",
            "municipio": "Municipio",
            "created_at": "Fecha de Alta"
        }
        df = df[list(cols_map.keys())].rename(columns=cols_map)
        
        # Formatear fecha
        df["Fecha de Alta"] = pd.to_datetime(df["Fecha de Alta"]).dt.strftime("%d/%m/%Y")
        
        # Crear Excel en memoria
        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df.to_excel(writer, index=False, sheet_name='Socios')
            
            # Ajustar ancho de columnas automáticamente (opcional pero profesional)
            worksheet = writer.sheets['Socios']
            for i, col in enumerate(df.columns):
                column_len = max(df[col].astype(str).str.len().max(), len(col)) + 2
                worksheet.column_dimensions[chr(65 + i)].width = min(column_len, 50)

        output.seek(0)
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": "attachment; filename=socios_sociedad_rural.xlsx"}
        )
    except Exception as e:
        print(f"Error en reporte excel: {e}")
        raise HTTPException(status_code=500, detail="Error al generar el reporte Excel")

@app.get("/api/admin/reports/contabilidad/csv")
def exportar_contabilidad_csv(admin_user = Depends(get_current_admin)):
    """Genera un reporte CSV especializado para contabilidad con resumen de categorías."""
    try:
        # 1. Obtener todos los perfiles
        res = supabase.table("profiles") \
            .select("nombre_apellido, dni, email, telefono, estado, municipio, rol, es_profesional, titular_id, created_at") \
            .execute()
        
        if not res.data:
            raise HTTPException(status_code=404, detail="No hay datos para exportar")
            
        data = res.data
        
        # 2. Calcular Conteos
        conteos = {
            "Socio Común": 0,
            "Grupo Familiar": 0,
            "Profesional": 0,
            "Comercial": 0,
            "Empleados": 0,
            "Total General (Al día)": 0
        }
        
        for p in data:
            rol = p.get("rol", "SOCIO")
            titular_id = p.get("titular_id")
            es_profesional = p.get("es_profesional", False)
            estado = p.get("estado", "PENDIENTE")
            
            # Clasificación
            if rol == "COMERCIO":
                if titular_id:
                    conteos["Empleados"] += 1
                else:
                    conteos["Comercial"] += 1
            else: # SOCIO o fallback
                if titular_id:
                    conteos["Grupo Familiar"] += 1
                elif es_profesional:
                    conteos["Profesional"] += 1
                else:
                    conteos["Socio Común"] += 1
            
            # Total al día
            if estado == "APROBADO":
                conteos["Total General (Al día)"] += 1

        # 3. Generar CSV en memoria (Delimitado por punto y coma para Excel)
        output = io.StringIO()
        # Añadir BOM para que Excel detecte UTF-8 correctamente
        output.write('\ufeff')
        
        writer = csv.writer(output, delimiter=';', quoting=csv.QUOTE_MINIMAL)
        
        # Encabezado del Reporte
        writer.writerow(["REPORTE DE CONTABILIDAD - SOCIEDAD RURAL"])
        writer.writerow(["Fecha de Generación", datetime.now().strftime("%d/%m/%Y %H:%M:%S")])
        writer.writerow([])
        
        # DETALLE DE SOCIOS (Arriba)
        writer.writerow(["DETALLE DE SOCIOS"])
        headers = ["Nombre y Apellido", "DNI/CUIT", "Email", "Teléfono", "Categoría", "Municipio", "Estado", "Fecha Alta"]
        writer.writerow(headers)
        
        # Filas de detalle
        for p in data:
            # Re-clasificar para mostrar en la columna Categoría
            rol = p.get("rol", "SOCIO")
            titular_id = p.get("titular_id")
            es_profesional = p.get("es_profesional", False)
            
            cat_label = "Socio Común"
            if rol == "COMERCIO":
                cat_label = "Empleado" if titular_id else "Comercio"
            else:
                if titular_id: cat_label = "Familiar (Adherente)"
                elif es_profesional: cat_label = "Profesional"
            
            fecha_alta = datetime.fromisoformat(p["created_at"].replace("Z", "+00:00")).strftime("%d/%m/%Y") if p.get("created_at") else "-"
            
            writer.writerow([
                p.get("nombre_apellido", "-"),
                p.get("dni", "-"),
                p.get("email", "-"),
                p.get("telefono", "-"),
                cat_label,
                p.get("municipio", "No especificado"),
                p.get("estado", "PENDIENTE"),
                fecha_alta
            ])

        writer.writerow([])
        writer.writerow([])
        
        # Sección de Resumen (Abajo)
        writer.writerow(["RESUMEN DE CATEGORÍAS"])
        writer.writerow(["Categoría", "Cantidad"])
        for cat, cant in conteos.items():
            writer.writerow([cat, cant])
            
        # 4. Retornar StreamingResponse
        output.seek(0)
        return StreamingResponse(
            io.BytesIO(output.getvalue().encode('utf-8-sig')),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment; filename=reporte_contabilidad_sr.csv"}
        )
    except Exception as e:
        print(f"Error en reporte contabilidad: {e}")
        raise HTTPException(status_code=500, detail="Error al generar el reporte de contabilidad")

@app.get("/api/admin/reports/socios/pdf")
def exportar_socios_pdf(admin_user = Depends(get_current_admin)):
    """Genera un reporte PDF con diseño institucional de los socios."""
    try:
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.lib import colors
        from reportlab.lib.units import cm
        
        res = supabase.table("profiles") \
            .select("nombre_apellido, dni, estado, telefono, municipio, rol") \
            .in_("rol", ["SOCIO", "COMERCIO", "ADMIN"]) \
            .execute()
        print(f"[REPORTS-PDF] Datos encontrados: {len(res.data) if res.data else 0}")
        data = res.data
        
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=landscape(A4), topMargin=20)
        elements = []
        
        styles = getSampleStyleSheet()
        
        # Logo Centrado
        logo_path = "logo.jpg"
        if os.path.exists(logo_path):
            img = Image(logo_path, width=4*cm, height=4*cm)
            img.hAlign = 'CENTER'
            elements.append(img)
            elements.append(Spacer(1, 10))

        # Título
        elements.append(Paragraph("<b>SOCIEDAD RURAL DEL NORTE DE CORRIENTES</b>", styles['Title']))
        elements.append(Paragraph("<b>INFORME ESTATUTARIO DE SOCIOS</b>", styles['Heading2']))
        elements.append(Spacer(1, 10))
        elements.append(Paragraph(f"Fecha de reporte: {datetime.now().strftime('%d/%m/%Y %H:%M')}", styles['Normal']))
        elements.append(Spacer(1, 20))
        
        # Tabla de datos
        table_data = [["SOCIO / NOMBRE Y APELLIDO", "DNI", "ESTADO", "TELÉFONO", "MUNICIPIO"]]
        for s in data:
            # Limpieza de datos Nones para evitar "None" en el PDF
            nombre = s.get("nombre_apellido") or "-"
            dni = s.get("dni") or "-"
            estado = s.get("estado") or "-"
            tel = s.get("telefono") or "-"
            muni = s.get("municipio") or "No especificado"
            
            table_data.append([
                str(nombre),
                str(dni),
                str(estado),
                str(tel),
                str(muni)
            ])
            
        # Diseño de la tabla
        t = Table(table_data, colWidths=[200, 80, 100, 100, 150])
        t.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.Color(0.1, 0.4, 0.2)), # Verde institucional sugerido
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
            ('TOPPADDING', (0, 0), (-1, 0), 10),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('FONTSIZE', (0, 1), (-1, -1), 9),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ]))
        elements.append(t)
        
        # Pie de página
        elements.append(Spacer(1, 30))
        elements.append(Paragraph("Documento emitido por el Sistema de Gestión Digital - Sociedad Rural.", styles['Italic']))
        
        doc.build(elements)
        buffer.seek(0)
        
        return StreamingResponse(buffer, media_type="application/pdf", headers={
            "Content-Disposition": "attachment; filename=reporte_socios.pdf"
        })
    except Exception as e:
        print(f"Error en reporte PDF: {e}")
        raise HTTPException(status_code=500, detail="Error al generar reporte PDF")

# ─────────────────────────────────────────────────────────────────────────────
# 14. WEBHOOK WHATSAPP (Chatbot de Consulta Automática)
@app.post("/api/whatsapp/webhook")
async def whatsapp_webhook(request: Request, background_tasks: BackgroundTasks):
    """
    Recibe eventos de Evolution API para responder consultas de socios de forma automática.
    """
    try:
        # LOG DE DEBUG en activity_log para verificar si el webhook es alcanzado
        try:
            # NO USAR request.body() aquí porque consume el stream y rompe el request.json() posterior
            supabase.table("activity_log").insert({
                "tipo_evento": "DEBUG_WEBHOOK",
                "descripcion": f"Webhook WhatsApp alcanzado. Headers: {dict(request.headers)}",
                "socio_id": None
            }).execute()
        except Exception as log_err:
            logger.error(f"[WEBHOOK] Error guardando log debug: {log_err}")

        # 1. Validar Token de Seguridad (si está configurado)
        secret_header = request.headers.get("webhook-secret")
        env_secret = os.getenv("WEBHOOK_SECRET_TOKEN")
        
        # Log inicial para debug
        logger.info(f"[WEBHOOK] Recibida petición. Header secret: {secret_header}")

        if env_secret and secret_header != env_secret:
             logger.warning(f"[WEBHOOK] Aviso: Webhook secret mismatch. Esperado: {env_secret}, Recibido: {secret_header}.")
             return {"status": "unauthorized", "detail": "Secret mismatch"}

        data = await request.json()
        event = data.get("event")
        
        # Solo procesamos la creación de nuevos mensajes
        if event != "messages.upsert":
            return {"status": "event-ignored"}

        message_data = data.get("data", {})
        key = message_data.get("key", {})
        
        if key.get("fromMe"):
            logger.info("[WEBHOOK] Mensaje ignorado porque es 'fromMe' (del propio bot).")
            return {"status": "self-message-ignored"}

        remote_jid = key.get("remoteJid", "")
        if not remote_jid.endswith("@s.whatsapp.net"):
            return {"status": "group-ignored"}

        numero_sender = remote_jid.split("@")[0] # ej: 5493794330172
        
        # Extraer texto del mensaje (soporta texto simple y mensajes con respuesta)
        msg_obj = message_data.get("message", {})
        msg_text = ""
        if "conversation" in msg_obj:
            msg_text = msg_obj["conversation"]
        elif "extendedTextMessage" in msg_obj:
            msg_text = msg_obj["extendedTextMessage"].get("text", "")
        
        msg_text_upper = msg_text.strip().upper()
        print(f"[WEBHOOK] De: {numero_sender} | Msg: {msg_text_upper}")

        # Palabras clave que activan el bot (petición de estado)
        keywords_estado = ["DEUDA", "ESTADO", "PAGOS", "VENCIMIENTO", "CUOTAS", "SALDO", "VENCIMIENTOS"]
        
        # Palabras clave afirmativas (respuestas a la notificación de mora)
        keywords_afirmacion = ["SI", "SÍ", "ACEPTO", "PAGAR", "QUIERO PAGAR", "DALE", "OK", "OKAY", "PAGO"]
        
        match_estado = any(kw in msg_text_upper for kw in keywords_estado)
        match_afirmacion = any(kw in msg_text_upper for kw in keywords_afirmacion)

        print(f"[WEBHOOK] Match Estado: {match_estado} | Match Afirmación: {match_afirmacion}")

        if match_estado or match_afirmacion:
            # Identificar al socio por los últimos 10 dígitos (formato Argentina)
            diez_digitos = "".join(filter(str.isdigit, numero_sender))[-10:]
            print(f"[WEBHOOK] Buscando socio con últimos 10 dígitos: {diez_digitos}")
            
            res_user = supabase.table("profiles") \
                .select("id, nombre_apellido, estado") \
                .ilike("telefono", f"%{diez_digitos}%") \
                .execute()
            
            if not res_user.data:
                print(f"[WEBHOOK] Socio no encontrado para el número: {diez_digitos}")
                return {"status": "user-not-found"}

            socio = res_user.data[0]
            print(f"[WEBHOOK] Socio encontrado: {socio['nombre_apellido']} (ID: {socio['id']})")
            
            # Buscar cuotas en estado PENDIENTE
            res_pagos = supabase.table("pagos_cuotas") \
                .select("monto, fecha_vencimiento") \
                .eq("socio_id", socio["id"]) \
                .eq("estado_pago", "PENDIENTE") \
                .order("fecha_vencimiento") \
                .execute()
            
            if not res_pagos.data:
                print(f"[WEBHOOK] El socio {socio['nombre_apellido']} no tiene deudas.")
                msg_ok = f"¡Hola {socio['nombre_apellido']}! 👋 No registramos cuotas pendientes a tu nombre. Tu cuenta está al día. ¡Muchas gracias!"
                background_tasks.add_task(enviar_whatsapp, numero_sender, msg_ok)
            else:
                total = sum(float(p["monto"]) for p in res_pagos.data)
                print(f"[WEBHOOK] Deuda total calculada para {socio['nombre_apellido']}: ${total}")
                detalle = ""
                for p in res_pagos.data:
                    # Formatear fecha YYYY-MM-DD a MM/YYYY
                    fv = p["fecha_vencimiento"].split("-")
                    detalle += f"• Cuota {fv[1]}/{fv[0]}: ${float(p['monto']):,.0f}\n"
                
                msg_deuda = (
                    f"Hola {socio['nombre_apellido']}! 👋\n\n"
                    f"Tu estado de cuenta actual registra:\n\n"
                    f"{detalle}\n"
                    f"*Total adeudado: ${total:,.0f}*\n\n"
                    "Podés abonar y subir tu comprobante de transferencia siguiendo este link:\n"
                    "https://sociedadruraldelnorte.agentech.ar/pagar-cuota\n\n"
                    "_Muchas gracias! Sociedad Rural del Norte de Corrientes._"
                )
                background_tasks.add_task(enviar_whatsapp, numero_sender, msg_deuda)
                
        return {"status": "success"}
    except Exception as e:
        print(f"Error procesando Webhook WhatsApp: {str(e)}")
        import traceback
        traceback.print_exc()
        return {"status": "error"}

# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
